"""Compare normalized I/Q and repeated-preamble features with a claimed-device gate."""

import argparse
import csv
from itertools import combinations
from pathlib import Path
from typing import NamedTuple

import numpy as np
from sklearn.covariance import LedoitWolf
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

from signal_features import (
    DEVELOPMENT_DEVICES, INDOOR, OUTDOOR, RESERVED_DEVICES, calculate_iq_moments,
    load_valid_frames, normalize_frames, phase_step_features, preamble_features,
)

FEATURE_SETS = ("iq_phase", "preamble")
PROTOCOLS = (
    ("indoor_trained_outdoor_calibrated", INDOOR, OUTDOOR, OUTDOOR, None),
    ("outdoor_fitted_later_outdoor", OUTDOOR, OUTDOOR, OUTDOOR, 34),
    ("outdoor_to_separate_indoor", OUTDOOR, OUTDOOR, INDOOR, 34),
    ("indoor_fitted_later_indoor", INDOOR, INDOOR, INDOOR, 34),
    ("indoor_to_separate_outdoor", INDOOR, INDOOR, OUTDOOR, 34),
)
CSV_COLUMNS = (
    "feature_set", "protocol", "training_condition", "profile_condition",
    "test_condition", "enrolled_ids", "device_id", "metric", "count", "total",
    "rate_percent",
)


def load_features(root):
    features = {}
    devices = DEVELOPMENT_DEVICES + RESERVED_DEVICES
    for condition in (INDOOR, OUTDOOR):
        for n in devices:
            path = root / condition / f"No_{n}_F5_1.mat"
            frames = load_valid_frames(path, min_samples=1130)
            if len(frames) <= 69:
                raise ValueError(f"{path} needs more than 69 usable frames.")
            for group, values in extract_gatekeeper_features(frames).items():
                features[condition, n, group] = values
    return features


def extract_gatekeeper_features(frames):
    window = normalize_frames(frames[:, 170:682], mode="dc_and_unit_rms")
    preamble = preamble_features(frames)
    return {
        "iq_phase": np.column_stack([calculate_iq_moments(window), phase_step_features(window)]),
        "preamble": np.column_stack([
            preamble[key] for key in (
                "repeated_phase", "repeat_error", "preamble_acf", "preamble_phase"
            )
        ]),
    }


def pack(features, condition, group, devices, selection):
    chunks = [features[condition, n, group][selection] for n in devices]
    return np.concatenate(chunks), np.repeat(devices, [len(x) for x in chunks])


def score_rows(model, features):
    return model.decision_function(features).reshape(len(features), -1)


class Verification(NamedTuple):
    distances: np.ndarray
    routed: np.ndarray
    accepted: np.ndarray
    selected: np.ndarray


def fit_gatekeeper(features, group, enrolled, protocol, *,
                   profile_frames=slice(34), train_on_profiles=False, upper_multiplier=1.0,
                   claim_reviewer=None):
    """Fit the verifier using early profile, calibration, and validation frames.

    Changing the upper cutoff controls which claims reach the SVM. The separate
    fast-pass cutoff still determines which claims Mahalanobis accepts directly.
    """
    _, train_cond, profile_cond, _, source_stop = protocol
    ref, ref_y = pack(features, profile_cond, group, enrolled, profile_frames)
    valid, valid_y = pack(features, profile_cond, group, enrolled, slice(51, 69))
    if claim_reviewer is None:
        if train_on_profiles:
            train_x, train_y = ref, ref_y
        else:
            train_x, train_y = pack(features, train_cond, group, enrolled, slice(source_stop))
        cal, cal_y = pack(features, profile_cond, group, enrolled, slice(34, 51))
        svm = make_pipeline(
            StandardScaler(), SVC(C=1, gamma="scale", decision_function_shape="ovo")
        ).fit(train_x, train_y)
        score_model = make_pipeline(
            StandardScaler(), LogisticRegression(C=1, max_iter=2000)
        ).fit(score_rows(svm, cal), cal_y)
    scale = StandardScaler().fit(ref)
    ref = scale.transform(ref)
    profiles = [LedoitWolf().fit(ref[ref_y == n]) for n in enrolled]

    def distances(x):
        x = scale.transform(x)
        return np.column_stack([profile.mahalanobis(x) for profile in profiles])

    valid_dist = distances(valid)
    genuine = valid_y[:, None] == enrolled
    lows, highs = [], []
    for j in range(len(enrolled)):
        lows.append(min(
            np.percentile(valid_dist[genuine[:, j], j], 90),
            np.nextafter(valid_dist[~genuine[:, j], j].min(), -np.inf),
        ))
        highs.append(np.percentile(valid_dist[genuine[:, j], j], 99))

    highs = np.asarray(highs) * upper_multiplier

    def verify(x, *, upper_cutoffs=None):
        d = distances(x)
        rejection_cutoffs = highs if upper_cutoffs is None else upper_cutoffs
        route = (d > lows) & (d <= rejection_cutoffs)
        accept = d <= lows
        selected = np.full(len(x), -1, dtype=int)
        needs_svm = route.any(axis=1)
        if claim_reviewer is not None:
            accept |= claim_reviewer(x, route)
        elif needs_svm.any():
            selected[needs_svm] = score_model.predict(score_rows(svm, x[needs_svm]))
            accept[needs_svm] |= route[needs_svm] & (selected[needs_svm, None] == enrolled)
        return Verification(d, route, accept, selected)

    return verify, lows, highs


def gatekeeper(features, group, enrolled, protocol):
    name, train_cond, profile_cond, test_cond, _ = protocol
    verify, _, _ = fit_gatekeeper(features, group, enrolled, protocol)

    window = slice(69, None) if profile_cond == test_cond else slice(None)
    test, test_y = pack(features, test_cond, group, enrolled, window)
    unknown, unknown_y = pack(features, test_cond, group, RESERVED_DEVICES, window)
    _, routed, accepted, _ = verify(test)
    unseen_accepted = verify(unknown).accepted.any(axis=1)
    correct = test_y[:, None] == enrolled
    genuine_accepted = accepted[correct]
    genuine_routed = routed[correct]

    def row(metric, outcomes, device_id=""):
        count, total = int(outcomes.sum()), outcomes.size
        return dict(zip(CSV_COLUMNS, (
            group, name, train_cond, profile_cond, test_cond, "|".join(map(str, enrolled)),
            device_id, metric, count, total, 100 * count / total,
        )))

    rows = [
        row("genuine_accepted", genuine_accepted),
        row("wrong_enrolled_id_accepted", accepted[~correct]),
        row("unseen_accepted_under_any_enrolled_id", unseen_accepted),
        row("genuine_routed", genuine_routed),
    ]
    for n in enrolled:
        rows.extend([
            row("genuine_accepted", genuine_accepted[test_y == n], int(n)),
            row("genuine_routed", genuine_routed[test_y == n], int(n)),
        ])
    for n in RESERVED_DEVICES:
        rows.append(row("unseen_accepted_under_any_enrolled_id", unseen_accepted[unknown_y == n], n))
    return rows


def evaluate(features, include_pairs=False):
    rows = []
    enrolled = np.array(DEVELOPMENT_DEVICES)
    for group in FEATURE_SETS:
        for protocol in PROTOCOLS:
            result = gatekeeper(features, group, enrolled, protocol)
            rows.extend(result)
            summary = ", ".join(f"{r['metric']} {r['rate_percent']:.2f}%" for r in result[:4])
            print(group, protocol[0], summary, flush=True)
        if include_pairs:
            for pair in combinations(enrolled, 2):
                for protocol in (PROTOCOLS[0], PROTOCOLS[2]):
                    rows.extend(gatekeeper(features, group, np.array(pair), protocol))
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, default=Path("gatekeeper_results.csv"))
    parser.add_argument("--pairs", action="store_true", help="Also evaluate all 66 enrolled-device pairs.")
    args = parser.parse_args()
    features = load_features(args.data_dir)
    rows = evaluate(features, include_pairs=args.pairs)
    with args.output.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, CSV_COLUMNS)
        writer.writeheader()
        writer.writerows(rows)
    print(f"Wrote {len(rows)} result rows to {args.output}")


if __name__ == "__main__":
    main()
