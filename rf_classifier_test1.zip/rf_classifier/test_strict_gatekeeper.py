"""Compare a calibrated SVM with a strict Mahalanobis fast pass and SVM fallback."""

import argparse
from pathlib import Path

import numpy as np
from sklearn.covariance import LedoitWolf
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

import evaluate_rf_classifier as evaluation


def svm_scores(svm, features):
    scores = svm.decision_function(features)
    # A binary SVM returns one score per frame. The calibrator needs a column.
    return scores.reshape(len(features), -1)


def find_fast_pass_cutoffs(profiles, validation, labels, devices):
    cutoffs = []
    for device, profile in zip(devices, profiles):
        distances = profile.mahalanobis(validation)
        genuine = labels == device
        genuine_limit = np.quantile(distances[genuine], 0.90)
        closest_other = distances[~genuine].min()

        # Fast pass uses <=, so the nearest wrong-device frame must sit above the cutoff.
        other_limit = np.nextafter(closest_other, -np.inf)
        cutoffs.append(min(genuine_limit, other_limit))
    return np.array(cutoffs)


def compare(train, enroll, calibration, validation, tests, devices):
    train_x, train_y = evaluation.stack_by_device(train, devices)
    calibration_x, calibration_y = evaluation.stack_by_device(calibration, devices)

    svm = make_pipeline(
        StandardScaler(),
        SVC(C=1, gamma="scale", decision_function_shape="ovo"),
    )
    svm.fit(train_x, train_y)

    calibrator = make_pipeline(
        StandardScaler(),
        LogisticRegression(C=1, max_iter=2000),
    )
    calibrator.fit(svm_scores(svm, calibration_x), calibration_y)

    profile_scaler = StandardScaler().fit(np.concatenate(enroll))
    profiles = [
        LedoitWolf().fit(profile_scaler.transform(device_frames))
        for device_frames in enroll
    ]
    validation_x, validation_y = evaluation.stack_by_device(validation, devices)
    cutoffs = find_fast_pass_cutoffs(
        profiles, profile_scaler.transform(validation_x), validation_y, devices
    )

    for label, frames in tests:
        test_x, test_y = evaluation.stack_by_device(frames, devices)
        print(f"\n{label} ({len(test_y)} frames)")

        # Each row is one frame. Each column is a claim for one device ID.
        genuine = test_y[:, None] == devices
        predicted_ids = calibrator.predict(svm_scores(svm, test_x))
        svm_accepts = predicted_ids[:, None] == devices

        scaled_test = profile_scaler.transform(test_x)
        distances = np.column_stack([
            profile.mahalanobis(scaled_test) for profile in profiles
        ])
        fast_pass = distances <= cutoffs
        routed_to_svm = ~fast_pass
        accepted = fast_pass | (routed_to_svm & svm_accepts)

        evaluation.report_verification(
            "Calibrated SVM", svm_accepts, genuine, np.ones_like(genuine)
        )
        evaluation.report_verification(
            "Strict fast pass + SVM", accepted, genuine, routed_to_svm
        )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, default=Path("dataset"))
    parser.add_argument("--devices", type=int, nargs="+", default=evaluation.DEFAULT_DEVICES)
    args = parser.parse_args()

    devices = np.array(sorted(set(args.devices)))
    if len(devices) < 2:
        parser.error("Select at least two distinct device IDs.")

    columns = evaluation.FEATURE_SETS["combined"]
    indoor = []
    outdoor = []
    for device in devices:
        indoor.append(evaluation.load_features(
            args.data_dir, "mat", evaluation.INDOOR, device, columns
        ).to_numpy())
        outdoor.append(evaluation.load_features(
            args.data_dir, "mat", evaluation.OUTDOOR, device, columns
        ).to_numpy())

    enrollment_end = 46
    validation_end = 69
    if any(len(frames) <= validation_end for frames in outdoor):
        parser.error("The recorded experiment requires more than 69 outdoor frames per device.")

    enrollment = [frames[:enrollment_end] for frames in outdoor]
    validation = [frames[enrollment_end:validation_end] for frames in outdoor]
    later_outdoor = [frames[validation_end:] for frames in outdoor]
    early_outdoor = [frames[:validation_end] for frames in outdoor]

    compare(
        train=indoor,
        enroll=enrollment,
        calibration=early_outdoor,
        validation=validation,
        tests=[("Indoor-trained SVM, later outdoor test frames", later_outdoor)],
        devices=devices,
    )
    compare(
        train=enrollment,
        enroll=enrollment,
        calibration=validation,
        validation=validation,
        tests=[
            ("Outdoor-trained SVM, later outdoor test frames", later_outdoor),
            ("Outdoor-trained SVM, separate indoor recordings", indoor),
        ],
        devices=devices,
    )


if __name__ == "__main__":
    main()
