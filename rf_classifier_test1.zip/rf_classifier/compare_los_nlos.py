"""Run matched LOS and NLOS evaluations of the claimed-device gatekeeper.

Place this file beside evaluate_preamble_gatekeeper.py and signal_features.py.
Use the four original scenario folders and the same device IDs in each.
"""

import argparse
import csv
import re
from pathlib import Path

import numpy as np

from evaluate_preamble_gatekeeper import CSV_COLUMNS, FEATURE_SETS, extract_gatekeeper_features, gatekeeper
from signal_features import DEVELOPMENT_DEVICES, RESERVED_DEVICES, load_indexed_frames

SCENARIOS = ("Indoor_LOS", "Outdoor_LOS", "Indoor_NLOS", "Outdoor_NLOS")
DEVICES = (*DEVELOPMENT_DEVICES, *RESERVED_DEVICES)
CALIBRATION_FRAMES = 69

METRICS = {
    "genuine_accepted": "Genuine accepted",
    "unseen_accepted_under_any_enrolled_id": "Unseen accepted",
    "wrong_enrolled_id_accepted": "Wrong known ID accepted",
    "genuine_routed": "Genuine claims routed",
}


def load_features(root):
    features, _ = load_capture_features(resolve_scenario_folders(root))
    return features


def load_capture_features(folders):
    paths = {
        (condition, device): folders[condition] / f"No_{device}_F5_1.mat"
        for condition in folders
        for device in DEVICES
    }
    missing = [path for path in paths.values() if not path.is_file()]
    if missing:
        examples = "\n  ".join(str(path) for path in missing[:6])
        raise ValueError(
            f"Found the scenario folders, but {len(missing)} required .mat files "
            f"are missing. Extract the original recordings for devices 1, 2, and 10–26 "
            f"into each scenario folder. First missing paths:\n  {examples}"
        )

    features, frame_numbers = {}, {}
    for (condition, device), path in paths.items():
        frames, frame_numbers[condition, device] = load_indexed_frames(path, min_samples=1130)
        if len(frames) <= CALIBRATION_FRAMES:
            raise ValueError(f"{path} needs more than {CALIBRATION_FRAMES} usable frames.")
        for group, values in extract_gatekeeper_features(frames).items():
            features[condition, device, group] = values
        print(f"Loaded {condition}/{path.name} ({len(frames)} frames)", flush=True)
    return features, frame_numbers


def scenario_folders(root):
    canonical = {name.lower(): name for name in SCENARIOS}
    folders = {}
    for path in sorted(root.iterdir()):
        name = canonical.get(re.sub(r"[-_\s]+", "_", path.name.strip().lower()))
        if not name or not path.is_dir():
            continue
        if name in folders:
            raise ValueError(f"Multiple folders match {name} under {root}.")
        folders[name] = path
    return folders


def resolve_scenario_folders(raw_root):
    root = raw_root.expanduser().resolve()
    hint = (
        "Pass --data-dir the path to your extracted ZigBee recordings. "
        "The classifier code ZIP contains no original .mat recordings."
    )
    if not root.is_dir():
        raise ValueError(f"Data directory does not exist: {root}\n{hint}")

    direct = scenario_folders(root)
    if len(direct) == len(SCENARIOS):
        return direct
    if direct:
        missing = ", ".join(name for name in SCENARIOS if name not in direct)
        raise ValueError(f"Scenario folders missing under {root}: {missing}.\n{hint}")

    # Some archives add a single outer folder when extracted.
    matches = []
    for child in sorted(root.iterdir()):
        if child.is_dir():
            folders = scenario_folders(child)
            if len(folders) == len(SCENARIOS):
                matches.append((child, folders))
    if len(matches) == 1:
        print(f"Using dataset folder: {matches[0][0]}")
        return matches[0][1]
    if matches:
        choices = "\n  ".join(str(path) for path, _ in matches)
        raise ValueError(f"Multiple extracted datasets found. Select one with --data-dir:\n  {choices}")
    raise ValueError(
        f"No scenario folders found under {root} or its immediate subfolders.\n{hint}"
    )


def comparison_protocol(visibility, mode):
    indoor, outdoor = f"Indoor_{visibility}", f"Outdoor_{visibility}"
    profile = indoor if mode == "indoor_only" else outdoor
    return f"{mode}_{visibility.lower()}", indoor, profile, outdoor, None


def evaluate(features):
    enrolled = np.array(DEVELOPMENT_DEVICES)
    # The verifier internally starts at frame 69 when profiling and testing use
    # the same condition. For indoor-only runs, trim the target here so both
    # protocols use exactly the same later outdoor frames and unknown devices.
    later = {
        key: values[CALIBRATION_FRAMES:] if key[0].startswith("Outdoor_") else values
        for key, values in features.items()
    }
    rows = []
    for group in FEATURE_SETS:
        for mode, data in (("indoor_only", later), ("outdoor_calibrated", features)):
            comparisons = {}
            for visibility in ("LOS", "NLOS"):
                protocol = comparison_protocol(visibility, mode)
                result = gatekeeper(data, group, enrolled, protocol)
                rows.extend(result)
                comparisons[visibility] = {
                    row["metric"]: row for row in result if row["device_id"] == ""
                }
            print(f"\n{group} | {mode}")
            print(f"{'Metric':<24} {'LOS':>22} {'NLOS':>22} {'LOS - NLOS':>12}")
            for metric, label in METRICS.items():
                los, nlos = (comparisons[condition][metric] for condition in ("LOS", "NLOS"))
                diff = los["rate_percent"] - nlos["rate_percent"]
                def format_rate(row):
                    return f"{row['rate_percent']:.2f}% ({row['count']}/{row['total']})"
                print(f"{label:<24} {format_rate(los):>22} {format_rate(nlos):>22} {diff:+9.2f} pp")
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, default=Path("los_nlos_comparison.csv"))
    args = parser.parse_args()

    try:
        rows = evaluate(load_features(args.data_dir))
        with args.output.open("w", encoding="utf-8", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=CSV_COLUMNS)
            writer.writeheader()
            writer.writerows(rows)
    except (ValueError, OSError) as error:
        parser.exit(2, f"{error}\n")
    print(f"\nWrote overall and per-device results to {args.output}")


if __name__ == "__main__":
    main()
