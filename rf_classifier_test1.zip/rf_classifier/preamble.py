from pathlib import Path
import numpy as np
from compare import DEVICES, DEVELOPMENT, RESERVED, load_frames, recording_path, run_eval

def phasor(x):
    return np.exp(1j*np.angle(x))

def extract(frames):
    blocks=frames[:,170:1130].reshape(len(frames),6,160)
    correlations=(blocks[:,1:]*blocks[:,:-1].conj()).sum(2)
    drift=phasor(correlations.sum(1))
    aligned=blocks*(drift[:,None,None]**(-np.arange(6)[None,:,None]))
    avg=aligned.mean(1)
    norm=avg/np.sqrt(np.mean(abs(avg)**2,axis=1,keepdims=True))
    dt=phasor(drift)
    fine=np.column_stack((dt.real,dt.imag))
    residual=np.mean(abs(aligned-avg[:,None,:])**2,axis=2)
    block_power=np.mean(abs(aligned)**2,axis=2)
    error=np.log10(np.maximum(residual/block_power,1e-12))
    spec=abs(np.fft.fft(norm,axis=1))**2
    spec/=spec.sum(1,keepdims=True)
    peak=np.argmax(spec,axis=1)
    shifted=np.take_along_axis(spec,(peak[:,None]+np.arange(-40,40))%160,axis=1)
    logspec=np.log10(shifted.reshape(len(frames),20,4).sum(2)+1e-10)
    acf=np.column_stack([abs(np.mean(np.roll(norm,k,axis=1)*norm.conj(),axis=1)) for k in [1,2,3,4,5,8,10,15,20,30,40,60,80]])
    lags=[1,2,3,4,5,8,10]
    fine_short=np.column_stack([np.angle(np.mean(np.roll(norm,k,axis=1)*norm.conj(),axis=1)) for k in lags])
    f=np.angle(np.mean(norm[:,1:]*norm[:,:-1].conj(),axis=1))/(2*np.pi)
    coarse=peak/160
    f=f+np.rint(coarse-f)
    combined_f=(np.angle(dt)/(2*np.pi)+np.rint(f*160-np.angle(dt)/(2*np.pi)))/160
    coarse_wrap=np.column_stack([np.cos(2*np.pi*coarse),np.sin(2*np.pi*coarse)])
    combined_wrap=np.column_stack([np.cos(2*np.pi*combined_f),np.sin(2*np.pi*combined_f)])
    return dict(repeated_phase=fine, preamble_shape=np.column_stack([acf,logspec]), repeat_error=error, preamble_phase=fine_short, peak_bin=coarse_wrap, phase_slope=combined_wrap)

data={}
with np.load('rf_scratch/features.npz') as old:
    for k in old.files:
        c,n,f=k.split('_',2)
        data.setdefault((c,int(n)),{})[f]=old[k]
for n in DEVICES:
    for c in ('in','out'):
        path=Path(f'rf_scratch/preamble_{c}_{n}.npz')
        if not path.exists():
            np.savez_compressed(path,**extract(load_frames(recording_path(c, n))))
        with np.load(path) as z:
            data[c,n].update({key:z[key] for key in z.files})
    print('Preamble extracted',n,flush=True)
groups={
    'repeated phase':['repeated_phase'],
    'repeat residual':['repeat_error'],
    'preamble shape':['preamble_shape'],
    'preamble shape and residual':['preamble_shape','repeat_error'],
    'preamble phase':['preamble_phase'],
    'spectral peak bin':['peak_bin'],
    'preamble phase slope':['phase_slope'],
    'preamble and long phase':['preamble_phase','long_phase','repeated_phase'],
    'preamble phase and power':['preamble_phase','absolute_power'],
}
best_name=None
best=-1
for name,g in groups.items():
    m=run_eval(data,DEVELOPMENT,g)
    total=m.trace()
    if total>best:
        best_name,best=name,total
    print('DEV',name,total,m.sum(),np.round(m.diagonal()/m.sum(1),3))
groups['phase512']=['phase512']
groups['power']=['absolute_power']
for nset,ids in [('RESERVED',RESERVED),('ALL',DEVICES)]:
    for name in [best_name,'phase512','power']:
        m=run_eval(data,ids,groups[name])
        print(nset,name,m.trace(),m.sum(),m.diagonal(),flush=True)
        np.save(f'rf_scratch/{nset}_{name.replace(" ","_")}.npy',m)
