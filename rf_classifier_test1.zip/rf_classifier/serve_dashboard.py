"""Serve the RF dashboard and calculate pair results from local recordings."""

import argparse
from functools import partial
from http import HTTPStatus
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
from urllib.parse import parse_qs, urlsplit
import webbrowser

from build_dashboard_data import SCENARIOS, load_metrics
from live_pair_evaluation import LiveRecordings, evaluate_pair
from signal_features import DEVELOPMENT_DEVICES

PROJECT = Path(__file__).resolve().parent


class DashboardHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, recordings, dashboard_data, sensors=None, radio=None, **kwargs):
        self.recordings = recordings
        self.dashboard_data = dashboard_data
        self.sensors = sensors
        self.radio = radio
        super().__init__(*args, directory=str(PROJECT / "dashboard"), **kwargs)

    def log_request(self, code="-", size="-"):
        # the live sensor panel polls every couple of seconds; keep those requests out of the console
        if not self.path.startswith(("/api/environment", "/api/radio")):
            super().log_request(code, size)

    def send_content(self, content, content_type, status=HTTPStatus.OK):
        body = content.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", f"{content_type}; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def send_json(self, value, status=HTTPStatus.OK):
        self.send_content(json.dumps(value, allow_nan=False), "application/json", status)

    def do_GET(self):
        request = urlsplit(self.path)
        if request.path == "/dashboard-data.js":
            script = "window.RF_DASHBOARD_DATA = " + json.dumps(self.dashboard_data) + ";"
            self.send_content(script, "application/javascript")
            return
        if request.path == "/api/environment":
            if self.sensors is None:
                self.send_json({"status": "off", "readings": [],
                                "message": "Start the server with --serial auto to read the Arduino."})
            else:
                self.send_json(self.sensors.snapshot())
            return
        if request.path in ("/api/radio", "/api/radio/config"):
            if self.radio is None:
                self.send_json({"source": None, "packets": [], "latest": None,
                                "message": "Start the server with --radio-replay to stream recorded packets."})
                return
            params = {key: values[0] for key, values in parse_qs(request.query).items()}
            try:
                if request.path == "/api/radio/config":
                    if "condition" in params:
                        self.radio.set_condition(params["condition"])
                    if "paused" in params:
                        self.radio.set_paused(params["paused"] == "1")
                    self.send_json(self.radio.status())
                else:
                    self.send_json(self.radio.since(int(params.get("since", 0))))
            except ValueError as error:
                self.send_json({"error": str(error)}, HTTPStatus.BAD_REQUEST)
            return
        if request.path not in ("/api/recording", "/api/pair"):
            super().do_GET()
            return

        params = {key: values[0] for key, values in parse_qs(request.query).items()}
        try:
            if request.path == "/api/recording":
                _, result, _ = self.recordings.recording(params["condition"], int(params["device"]))
            else:
                result = evaluate_pair(
                    self.recordings,
                    (int(params["first"]), int(params["second"])),
                    params["training"],
                    params["testing"],
                    params["configuration"],
                    tier2=params.get("tier2", "device_classifier"),
                )
            self.send_json(result)
        except KeyError as error:
            self.send_json({"error": f"Missing request field {error}."}, HTTPStatus.BAD_REQUEST)
        except (OSError, ValueError) as error:
            self.send_json({"error": str(error)}, HTTPStatus.BAD_REQUEST)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, required=True)
    parser.add_argument("--comparison", type=Path, help="Optional saved LOS/NLOS comparison CSV.")
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--no-open", action="store_true", help="Print the address without opening a browser.")
    parser.add_argument("--serial", metavar="PORT",
                        help="Read live sensor data from the Arduino: a port such as /dev/cu.usbmodem113201 or COM3, or 'auto'.")
    parser.add_argument("--baud", type=int, default=115200, help="Must match Serial.begin() in the Arduino sketch.")
    parser.add_argument("--sensor-log", type=Path, default=PROJECT / "sensor_log.csv",
                        help="CSV file that every Arduino reading is appended to (default: sensor_log.csv here).")
    parser.add_argument("--radio-replay", nargs="?", const="Indoor_NLOS", metavar="CONDITION",
                        help="Stream recorded packets as a live-style radio feed (default condition: Indoor_NLOS).")
    args = parser.parse_args()
    sensors = None
    if args.serial:
        from arduino_bridge import ArduinoBridge
        sensors = ArduinoBridge(args.serial, args.baud, log_path=args.sensor_log.expanduser()).start()
    try:
        recordings = LiveRecordings(args.data_dir.expanduser().resolve())
        inventory = recordings.inventory()
        conditions = {item["condition"] for item in inventory}
        metrics = load_metrics(PROJECT / "gatekeeper_results.csv")
        comparison = args.comparison or PROJECT / "los_nlos_comparison.csv"
        if args.comparison or comparison.is_file():
            metrics.extend(load_metrics(comparison))
        data = {
            "live": True,
            "cohort_ids": "|".join(map(str, DEVELOPMENT_DEVICES)),
            "scenarios": {name: info for name, info in SCENARIOS.items() if name in conditions},
            "recordings": inventory,
            "results": [
                row for row in metrics
                if all(row[field] in conditions for field in (
                    "training_condition", "profile_condition", "test_condition"
                ))
            ],
        }
        radio = None
        if args.radio_replay:
            from radio_feed import RadioFeed
            radio = RadioFeed(recordings.paths, sensors=sensors, condition=args.radio_replay).start()
        handler = partial(DashboardHandler, recordings=recordings, dashboard_data=data, sensors=sensors, radio=radio)
        server = ThreadingHTTPServer(("127.0.0.1", args.port), handler)
    except (OSError, ValueError) as error:
        parser.exit(2, f"{error}\n")

    address = f"http://127.0.0.1:{server.server_port}/"
    print(f"RF dashboard: {address}", flush=True)
    print(f"Found {len(inventory)} recordings in {len(conditions)} conditions. Press Ctrl+C to stop.", flush=True)
    if sensors:
        print(f"Reading the Arduino on {args.serial} at {args.baud} baud; saving readings to {sensors.log_path}", flush=True)
    if radio:
        print(f"Radio feed: replaying recorded {radio.condition} packets (no SDR attached).", flush=True)
    with server:
        if not args.no_open:
            webbrowser.open(address)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass


if __name__ == "__main__":
    main()
