"""Binary Tier 2 SVM models that independently verify each claimed device ID."""

import numpy as np
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

from signal_features import DEVELOPMENT_DEVICES

SCORE_VALIDATION_FRAMES = slice(34, 51)


def split_extra_devices(recordings, enrolled, training_condition, test_condition):
    """Keep extra development devices used for training and validation disjoint."""
    candidates = [device for device in DEVELOPMENT_DEVICES if device not in enrolled]
    training_devices = [
        device for device in candidates[::2] if (training_condition, device) in recordings.paths
    ]
    validation_devices = [
        device for device in candidates[1::2] if (test_condition, device) in recordings.paths
    ]
    return training_devices, validation_devices


def fit_claim_reviewer(recordings, enrolled, training_condition, test_condition,
                       feature_name, sample_start, profile_frames):
    training_devices, validation_devices = split_extra_devices(
        recordings, enrolled, training_condition, test_condition
    )

    def load(condition, device):
        return recordings.features(condition, int(device), feature_name, sample_start)

    def training_frames(device):
        samples = load(training_condition, device)
        if training_condition == test_condition:
            return samples[profile_frames[profile_frames < len(samples)]]
        return samples

    training_by_device = {
        device: training_frames(device) for device in (*enrolled, *training_devices)
    }
    validation_by_device = {
        device: load(test_condition, device)[SCORE_VALIDATION_FRAMES]
        for device in (*enrolled, *validation_devices)
    }

    models = []
    cutoffs = []
    for claimed_device in enrolled:
        genuine = training_by_device[claimed_device]
        other = np.concatenate([
            samples for device, samples in training_by_device.items() if device != claimed_device
        ])
        samples = np.vstack([genuine, other])
        labels = np.repeat([True, False], [len(genuine), len(other)])
        model = make_pipeline(StandardScaler(), SVC(C=1, class_weight="balanced"))
        model.fit(samples, labels)

        wrong_id_validation = np.concatenate([
            samples for device, samples in validation_by_device.items() if device != claimed_device
        ])
        # At least the other enrolled device supplies a separate validation block.
        closest_wrong_score = model.decision_function(wrong_id_validation).max()
        cutoffs.append(max(0.0, np.nextafter(closest_wrong_score, np.inf)))
        models.append(model)

    def review(samples, routed):
        accepted = np.zeros(routed.shape, dtype=bool)
        for column, (model, cutoff) in enumerate(zip(models, cutoffs)):
            claims = routed[:, column]
            if claims.any():
                accepted[claims, column] = model.decision_function(samples[claims]) >= cutoff
        return accepted

    return review, training_devices, validation_devices
