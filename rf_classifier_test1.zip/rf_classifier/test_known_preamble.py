from pathlib import Path

import numpy as np
from scipy.signal import fftconvolve
from compare import recording_path
import evaluate_rf_classifier as e

CHIPS = {
    0: "11011001110000110101001000101110",
    7: "10011100001101010010001011101101",
    10: "01111011100011001001011000000111",
}
CHIP_SAMPLES = 5
SYMBOL_SAMPLES = 160
SKIP = 2 * SYMBOL_SAMPLES
SFD = 8 * SYMBOL_SAMPLES
SFD_TEST_MIN = 0.55
PREAMBLE_TEST_MIN = 0.55
SEARCH_SAMPLES = 2400
PREFIX_LEN = SEARCH_SAMPLES + SFD - SKIP + 2 * SYMBOL_SAMPLES
DEVICES = np.array(e.DEFAULT_DEVICES)


def reference_waveform(symbols):
    chips = np.array([int(chip) * 2 - 1 for symbol in symbols for chip in CHIPS[symbol]])
    pulse = np.sin(np.pi * np.arange(2 * CHIP_SAMPLES) / (2 * CHIP_SAMPLES))
    out = np.zeros(len(chips) * CHIP_SAMPLES + CHIP_SAMPLES, complex)
    for i, chip in enumerate(chips):
        j = i * CHIP_SAMPLES
        out[j:j+len(pulse)] += chip * pulse * (1j if i % 2 else 1)
    return out


def differential(wave):
    a, b = wave[..., :-1], wave[..., 1:]
    d = b * a.conj()
    magnitude = abs(d)
    return np.divide(d, magnitude, out=np.zeros_like(d), where=magnitude > 0)


def match(signal, template):
    centered = template - template.mean()
    norm = np.linalg.norm(centered)
    length = len(centered)
    cum = np.pad(np.cumsum(signal, axis=1), ((0, 0), (1, 0)))
    cum_power = np.pad(np.cumsum(abs(signal)**2, axis=1), ((0, 0), (1, 0)))
    power = np.maximum(0, cum_power[:, length:] - cum_power[:, :-length]
                       - abs(cum[:, length:] - cum[:, :-length])**2 / length)
    numerator = abs(fftconvolve(signal, centered[None, ::-1].conj(), mode="valid", axes=-1))
    denom = norm * np.sqrt(power)
    return np.divide(numerator, denom, out=np.zeros_like(numerator), where=denom > 1e-12)


reference = reference_waveform([0] * 8 + [7, 10])
template_pre = differential(reference[SKIP:SFD])
template_sfd = differential(reference[SFD:SFD+2*SYMBOL_SAMPLES])


def detect(frames):
    signal = differential(frames)
    best_score = np.full(len(frames), -1.0)
    best_start = np.zeros(len(frames), int)
    pre_found = np.zeros(len(frames))
    sfd_found = np.zeros(len(frames))
    row = np.arange(len(frames))
    sfd_offset = SFD - SKIP
    for variant in (signal, signal.conj()):
        pre = match(variant, template_pre)[:, :SEARCH_SAMPLES]
        # Check the actual delimiter at the expected offset, not only repeated symbols.
        sfd = match(variant, template_sfd)[:, sfd_offset:sfd_offset + SEARCH_SAMPLES]
        score = np.minimum(pre, sfd)
        pos = score.argmax(axis=1)
        scores = score[row, pos]
        improved = scores > best_score
        best_score[improved] = scores[improved]
        best_start[improved] = pos[improved]
        pre_found[improved] = pre[row, pos][improved]
        sfd_found[improved] = sfd[row, pos][improved]
    return best_start, pre_found, sfd_found


def features(windows):
    prev, nxt = windows[:, :-1], windows[:, 1:]
    valid = (prev != 0) & (nxt != 0)
    angle = np.angle(nxt * prev.conj())
    count = valid.sum(axis=1)
    result = np.column_stack([
        e.calculate_iq_moments(windows),
        (np.sin(angle)*valid).sum(axis=1) / count,
        (np.cos(angle)*valid).sum(axis=1) / count,
    ])
    assert np.isfinite(result).all()
    return result


def normalization(w):
    centered = w - w.mean(axis=1, keepdims=True)
    return centered / np.sqrt(np.mean(abs(centered)**2, axis=1, keepdims=True))


def load_frames(path):
    samples, indices = e.read_mat(path)
    start, end = indices.astype(int).T
    assert np.all(end - start + 1 >= PREFIX_LEN)
    return samples[(start - 1)[:, None] + np.arange(PREFIX_LEN)]


def collect():
    # Test the timing detector with a known synthetic offset, phase, gain and CFO.
    # The carrier rotation cancels as a constant phase in the differential match.
    n = np.arange(len(reference))
    synthetic = np.r_[np.zeros(109, complex),
                      0.7 * reference * np.exp(1j*(0.31 + 0.049*n)),
                      np.zeros(PREFIX_LEN-109-len(reference), complex)]
    expected = 109 + SKIP
    found, pre, sfd = detect(synthetic[None, :])
    assert abs(found[0] - expected) <= 1 and pre[0] > .99 and sfd[0] > .99
    print("Synthetic preamble", found[0], expected, pre[0], sfd[0], flush=True)
    data = {}
    for n in DEVICES:
        for condition in ("in", "out"):
            frames = load_frames(recording_path(condition, n))
            starts, pre, sfd = detect(frames)
            trusted = (pre >= PREAMBLE_TEST_MIN) & (sfd >= SFD_TEST_MIN)
            data[f"{condition}_{n}_diag"] = np.column_stack([starts-SKIP, pre, sfd, trusted])
            fixed = frames[:, 170:682]
            aligned = frames[np.arange(len(frames))[:, None], starts[:, None] + np.arange(512)]
            fallback = np.where(trusted[:, None], aligned, fixed)
            for mode, windows in [("fixed", fixed), ("aligned", aligned), ("fallback", fallback)]:
                data[f"{condition}_{n}_{mode}"] = features(windows)
                data[f"{condition}_{n}_{mode}_norm"] = features(normalization(windows))
        print("Checked device", n, flush=True)
    return data


if __name__ == "__main__":
    cache = Path("rf_scratch/known_preamble_features.npz")
    if not cache.exists():
        cache.parent.mkdir(exist_ok=True)
        np.savez_compressed(cache, **collect())
    with np.load(cache) as d:
        for condition in ("in", "out"):
            all_diag = np.vstack([d[f"{condition}_{n}_diag"] for n in DEVICES])
            matches = all_diag[:,3].astype(bool)
            print(condition, "coverage", sum(matches), len(matches),
                  "median start/pre/sfd", np.median(all_diag[matches,:3],axis=0),
                  "all score quantiles", np.quantile(all_diag[:,1:3],[.1,.5,.9],axis=0))
            print("coverage per device", [(int(n),int(d[f"{condition}_{n}_diag"][:,3].sum())) for n in DEVICES])
        for method in ("fixed","aligned","fallback","fixed_norm","aligned_norm","fallback_norm"):
            x, y = e.stack_by_device([d[f"in_{n}_{method}"] for n in DEVICES], DEVICES)
            xc,yc = e.stack_by_device([d[f"out_{n}_{method}"][:69] for n in DEVICES],DEVICES)
            xt,yt = e.stack_by_device([d[f"out_{n}_{method}"][69:] for n in DEVICES],DEVICES)
            model = e.make_pipeline(e.StandardScaler(),e.SVC(decision_function_shape="ovo")).fit(x,y)
            cal = e.make_pipeline(e.StandardScaler(),e.LogisticRegression(C=1,max_iter=2000))
            cal.fit(model.decision_function(xc),yc)
            p, q = model.predict(xt), cal.predict(model.decision_function(xt))
            print(method, 'cross-condition', (p==yt).sum(), 'calibrated', (q==yt).sum(), 'of',len(yt), flush=True)
