"""Fit and evaluate a two-device verifier using the selected recordings."""

from threading import Lock

import numpy as np

from build_dashboard_data import SCENARIOS, recording_preview
from compare_los_nlos import scenario_folders
from evaluate_preamble_gatekeeper import fit_gatekeeper, pack
from signal_features import (
    DEFAULT_DEVICES, DEVELOPMENT_DEVICES, RESERVED_DEVICES, calculate_iq_moments,
    indexed_frame_windows, normalize_frames, phase_step_features, preamble_features,
    read_mat,
)
from svm_claim_verifier import fit_claim_reviewer

SETUP_FRAMES = 69
BASE_PROFILE_FRAMES = 34
MAX_PROFILE_FRAMES = 100
PREAMBLE_GROUPS = ("repeated_phase", "repeat_error", "preamble_acf", "preamble_phase")
FEATURE_LABELS = {
    "iq_phase": "512-sample I/Q + phase",
    "preamble": "Preamble",
    "preamble_iq": "Preamble + I/Q statistics",
}
CONFIGURATIONS = (
    "candidate", "candidate_original", "candidate_wider", "candidate_adaptive", "preamble", "iq_phase",
)


def dataset_recordings(root):
    """Find supported recordings without loading their sample arrays."""
    folders = scenario_folders(root)
    if not folders:
        matches = [scenario_folders(child) for child in sorted(root.iterdir()) if child.is_dir()]
        matches = [match for match in matches if match]
        if len(matches) != 1:
            raise ValueError("Point --data-dir to the dataset folder containing the condition folders.")
        folders = matches[0]
    paths = {}
    for condition in SCENARIOS:
        if condition not in folders:
            continue
        for device in DEFAULT_DEVICES:
            path = folders[condition] / f"No_{device}_F5_1.mat"
            if path.is_file():
                paths[condition, device] = path
    if not paths:
        raise ValueError(f"No supported No_<device>_F5_1.mat recordings were found in {root}.")
    return paths


def feature_table(frames, feature_name, start):
    if feature_name == "preamble":
        blocks = preamble_features(frames, start=start)
        return np.column_stack([blocks[name] for name in PREAMBLE_GROUPS])
    window = normalize_frames(frames[:, start:start + 512])
    iq_moments = calculate_iq_moments(window)
    if feature_name == "iq_phase":
        return np.column_stack([iq_moments, phase_step_features(window)])
    blocks = preamble_features(frames, start=start)
    return np.column_stack([*(blocks[name] for name in PREAMBLE_GROUPS), iq_moments])


def settings_for(condition, configuration):
    if configuration == "iq_phase":
        return "iq_phase", 170, 1.0
    if configuration == "preamble":
        return "preamble", 170, 1.0

    feature_name, start, upper = {
        "Indoor_NLOS": ("preamble_iq", 170, 1.5),
        "Outdoor_NLOS": ("preamble", 320, 1.0),
    }.get(condition, ("preamble", 170, 1.0))
    if configuration in ("candidate_original", "candidate_adaptive"):
        upper = 1.0
    elif configuration == "candidate_wider":
        upper = 1.5
    return feature_name, start, upper


def count_rate(outcomes):
    return {"count": int(outcomes.sum()), "total": int(outcomes.size)}


class LiveRecordings:
    def __init__(self, root):
        self.paths = dataset_recordings(root)
        self.lock = Lock()
        self.recording_cache = {}
        self.feature_cache = {}

    def inventory(self):
        return [
            {
                "condition": condition,
                "device": device,
                "file": f"{path.parent.name}/{path.name}",
                "size": path.stat().st_size,
                "enrolled": device in DEVELOPMENT_DEVICES,
            }
            for (condition, device), path in self.paths.items()
        ]

    def recording(self, condition, device):
        key = (condition, device)
        path = self.paths.get(key)
        if path is None:
            raise ValueError(f"No_{device} has no recording in {condition}.")
        version = path.stat().st_mtime_ns
        with self.lock:
            cached = self.recording_cache.get(key)
            if cached is None or cached[0] != version:
                samples, indices = read_mat(path)
                preview = recording_preview(path, condition, device, samples, indices)
                frames, _ = indexed_frame_windows(samples, indices, 1280, path)
                cached = version, preview, frames
                self.recording_cache[key] = cached
                if len(self.recording_cache) > 12:
                    self.recording_cache.pop(next(iter(self.recording_cache)))
        return cached

    def features(self, condition, device, feature_name, start):
        key = (condition, device, feature_name, start)
        path = self.paths.get((condition, device))
        if path is None:
            raise ValueError(f"No_{device} needs a recording in {condition} for this run.")
        version = path.stat().st_mtime_ns
        cached = self.feature_cache.get(key)
        if cached is None or cached[0] != version:
            version, _, frames = self.recording(condition, device)
            cached = version, feature_table(frames, feature_name, start)
            self.feature_cache[key] = cached
        return cached[1]


def tune_upper_cutoffs(verify, upper_cutoffs, samples, labels, enrolled):
    """Widen an individual review band if validation genuine claims benefit."""
    genuine = labels[:, None] == enrolled
    original = verify(samples)
    allowed_wrong = (original.accepted & ~genuine).sum(axis=0)
    best_genuine = (original.accepted & genuine).sum(axis=0)
    multipliers = np.ones(len(enrolled))
    for multiplier in (1.25, 1.5, 2.0):
        candidate = verify(samples, upper_cutoffs=upper_cutoffs * multiplier)
        correct = (candidate.accepted & genuine).sum(axis=0)
        wrong = (candidate.accepted & ~genuine).sum(axis=0)
        better = (correct > best_genuine) & (wrong <= allowed_wrong)
        multipliers[better] = multiplier
        best_genuine[better] = correct[better]
    return upper_cutoffs * multipliers, multipliers


def audit_rejections(verify, samples, result, cutoffs):
    """Ask the SVM about claims that the active verifier rejected at Tier 1."""
    rejected_at_gate = (result.distances > cutoffs) & ~result.accepted
    audit = verify(samples, upper_cutoffs=np.inf)
    return rejected_at_gate, rejected_at_gate & audit.accepted


def evaluate_pair(recordings, devices, training_condition, test_condition, configuration, *,
                  tier2="device_classifier"):
    if len(devices) != 2 or len(set(devices)) != 2:
        raise ValueError("Select two different devices.")
    if configuration not in CONFIGURATIONS:
        raise ValueError("Choose a listed verifier configuration.")
    if tier2 not in ("device_classifier", "claim_verifier"):
        raise ValueError("Choose a listed Tier 2 model.")
    enrolled = np.array(sorted(devices))
    feature_name, start, upper_multiplier = settings_for(test_condition, configuration)
    features = {}
    for condition in dict.fromkeys((test_condition, training_condition)):
        for device in enrolled:
            values = recordings.features(condition, int(device), feature_name, start)
            if len(values) == 0:
                raise ValueError(f"No_{device} has no usable frames in {condition}.")
            features[condition, device, feature_name] = values

    shortest = min(len(features[test_condition, device, feature_name]) for device in enrolled)
    if shortest <= SETUP_FRAMES:
        raise ValueError(f"Both selected devices need more than {SETUP_FRAMES} usable test-condition frames.")
    # Match the NLOS experiment's split and adapt to shorter captures, including LOS.
    test_start = min(160, max(SETUP_FRAMES, shortest * 7 // 10))
    extra_profiles = min(MAX_PROFILE_FRAMES - BASE_PROFILE_FRAMES, test_start - SETUP_FRAMES)
    profile_frames = np.r_[0:BASE_PROFILE_FRAMES, SETUP_FRAMES:SETUP_FRAMES + extra_profiles]
    held_out = slice(test_start, None)

    unseen_frames = []
    unseen_ids = []
    for device in RESERVED_DEVICES:
        if device in enrolled or (test_condition, device) not in recordings.paths:
            continue
        values = recordings.features(test_condition, device, feature_name, start)[held_out]
        if len(values):
            unseen_frames.append(values)
            unseen_ids.append(device)

    claim_reviewer = None
    extra_training, extra_validation = [], []
    if tier2 == "claim_verifier":
        claim_reviewer, extra_training, extra_validation = fit_claim_reviewer(
            recordings, enrolled, training_condition, test_condition, feature_name, start, profile_frames
        )

    protocol = ("live_pair", training_condition, test_condition, test_condition, None)
    verify, _, upper_cutoffs = fit_gatekeeper(
        features, feature_name, enrolled, protocol, profile_frames=profile_frames,
        train_on_profiles=training_condition == test_condition, upper_multiplier=upper_multiplier,
        claim_reviewer=claim_reviewer,
    )
    device_cutoff_multipliers = np.full(len(enrolled), upper_multiplier)
    validation_frames = 0
    if configuration == "candidate_adaptive":
        validation_start = max(SETUP_FRAMES + extra_profiles, test_start - 25)
        validation_frames = test_start - validation_start
        if validation_frames:
            samples, validation_ids = pack(
                features, test_condition, feature_name, enrolled, slice(validation_start, test_start)
            )
            upper_cutoffs, device_cutoff_multipliers = tune_upper_cutoffs(
                verify, upper_cutoffs, samples, validation_ids, enrolled
            )

    test_x, labels = pack(features, test_condition, feature_name, enrolled, held_out)
    result = verify(test_x, upper_cutoffs=upper_cutoffs)
    gate_rejected, audit_accepted = audit_rejections(verify, test_x, result, upper_cutoffs)
    genuine = labels[:, None] == enrolled
    wrong_id_accepted = (result.accepted & ~genuine).any(axis=1)
    genuine_accepted = result.accepted[genuine]
    genuine_fast_pass = (result.accepted & ~result.routed)[genuine]
    genuine_svm_pass = (result.accepted & result.routed)[genuine]
    device_results = []
    for device, other_device in zip(enrolled, enrolled[::-1]):
        sent_by_device = labels == device
        device_rejected = gate_rejected[genuine][sent_by_device]
        device_audit_accepts = audit_accepted[genuine][sent_by_device]
        device_results.append({
            "id": int(device),
            "wrong_claim_id": int(other_device),
            "wrong_claim_accepted": count_rate(wrong_id_accepted[sent_by_device]),
            "accepted": count_rate(genuine_accepted[sent_by_device]),
            "fast_pass": count_rate(genuine_fast_pass[sent_by_device]),
            "svm_accept": count_rate(genuine_svm_pass[sent_by_device]),
            "gate_rejected": count_rate(device_rejected),
            "audit_recovered": count_rate(device_audit_accepts[device_rejected]),
        })

    unseen_accepted = np.zeros(0, dtype=bool)
    unseen_routed = np.zeros(0, dtype=bool)
    audit_unseen_accepts = np.zeros(0, dtype=bool)
    if unseen_frames:
        unseen_samples = np.concatenate(unseen_frames)
        unseen = verify(unseen_samples, upper_cutoffs=upper_cutoffs)
        unseen_accepted = unseen.accepted.any(axis=1)
        unseen_routed = unseen.routed.any(axis=1)
        _, audit_unseen = audit_rejections(verify, unseen_samples, unseen, upper_cutoffs)
        audit_unseen_accepts = audit_unseen.any(axis=1) & ~unseen_accepted
    return {
        "devices": device_results,
        "tier2": tier2,
        "tier2_extra_training_ids": extra_training,
        "tier2_extra_validation_ids": extra_validation,
        "training_condition": training_condition,
        "test_condition": test_condition,
        "features": FEATURE_LABELS[feature_name],
        "sample_start": start,
        "upper_multiplier": upper_multiplier,
        "adaptive_cutoff": configuration == "candidate_adaptive",
        "cutoff_validation_frames": validation_frames,
        "device_cutoff_multipliers": device_cutoff_multipliers.tolist(),
        "audit_new_wrong_id_accepts": count_rate(
            (audit_accepted & ~genuine).any(axis=1) & ~wrong_id_accepted
        ),
        "audit_new_unseen_accepts": count_rate(audit_unseen_accepts),
        "profile_count": int(len(profile_frames)),
        "first_test_frame": test_start + 1,
        "unseen_ids": unseen_ids,
        "metrics": {
            "genuine_acceptance": count_rate(genuine_accepted),
            "wrong_known": count_rate(wrong_id_accepted),
            "unseen_acceptance": count_rate(unseen_accepted),
            "svm_review": count_rate(np.r_[result.routed.any(axis=1), unseen_routed]),
        },
    }
