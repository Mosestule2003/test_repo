"""Stream recorded ZigBee packets as a live-style feed for the dashboard.

There is no SDR attached, so RadioFeed plays back packets from the ZigBee_RFF
recordings the way a receiver would hear them: one packet at a time, from a
random transmitter, every 0.6-1.6 seconds. Each packet is measured as it
"arrives" (power, signal quality, carrier frequency offset) and stamped with
the Arduino's environment reading at that moment. Every packet is labelled
with the recording it came from, so the feed is never mistaken for a capture.
"""

import random
import threading
import time
from collections import deque
from datetime import datetime, timezone

import numpy as np

from signal_features import read_mat

FS = 10e6                 # sample rate (inferred for ZigBee_RFF; same assumption as the rest of the project)
SYM = 160                 # one preamble symbol = 16 us
KEEP = 2048               # samples kept per packet (preamble + start of payload)
PREVIEW = 768             # samples sent to the dashboard for the waveform plot


def _preamble_start(p, length=6 * SYM, search=800):
    """Where the packet best repeats itself every 160 samples (the preamble)."""
    x = p[: search + length + SYM]
    c = x[SYM:] * np.conj(x[:-SYM]); e = np.abs(x[SYM:]) ** 2
    cc = np.concatenate([[0], np.cumsum(c)]); ce = np.concatenate([[0], np.cumsum(e)])
    d = np.arange(0, min(search, len(c) - length))
    m = np.abs(cc[d + length] - cc[d]) / (ce[d + length] - ce[d] + 1e-20)
    return int(d[np.argmax(m)])


def coarse_cfo(prefix):
    """Rough carrier offset of one packet: average frequency over its preamble (noisy at low SNR)."""
    d = _preamble_start(prefix)
    seg = prefix[d: d + 6 * SYM + 1]
    return float(np.mean(np.angle(seg[1:] * np.conj(seg[:-1])))) * FS / (2 * np.pi)


def measure(prefix, full_power, n_samples, coarse):
    """Per-packet measurements a receiver would log."""
    d = _preamble_start(prefix)
    seg = prefix[d: d + 6 * SYM + SYM]
    ph = np.angle(np.sum(seg[SYM: 7 * SYM] * np.conj(seg[: 6 * SYM])))
    cfo = coarse + np.angle(np.exp(1j * (ph - 2 * np.pi * coarse * SYM / FS))) * FS / (2 * np.pi * SYM)
    a = np.abs(prefix[d:])
    snr = 10 * np.log10(a.mean() ** 2 / (a.var() + 1e-20))
    return {
        "cfo_hz": round(float(cfo), 1),
        "snr_db": round(float(snr), 1),
        "power_dbfs": round(float(10 * np.log10(full_power + 1e-20)), 1),
        "duration_ms": round(n_samples / FS * 1e3, 2),
    }


class RadioFeed:
    def __init__(self, paths, sensors=None, condition=None, history=300):
        self.paths = paths                                  # {(condition, device): Path}
        self.sensors = sensors
        self.conditions = sorted({c for c, _ in paths})
        self.condition = condition if condition in self.conditions else self.conditions[0]
        self.devices = {}                                   # device -> {"frames": [...], "next": i}
        self.loading = set()
        self.packets = deque(maxlen=history)
        self.seq = 0
        self.paused = False
        self.lock = threading.Lock()
        self.generation = 0                                 # bumps when the condition changes

    # ---------- loading ----------
    def start(self):
        threading.Thread(target=self._load_loop, name="radio-load", daemon=True).start()
        threading.Thread(target=self._emit_loop, name="radio-emit", daemon=True).start()
        return self

    def set_condition(self, condition):
        if condition not in self.conditions:
            raise ValueError(f"Unknown condition {condition}.")
        with self.lock:
            if condition != self.condition:
                self.condition = condition
                self.devices = {}
                self.generation += 1
        return self.status()

    def set_paused(self, paused):
        with self.lock:
            self.paused = bool(paused)
        return self.status()

    def _load_loop(self):
        while True:
            with self.lock:
                gen, cond = self.generation, self.condition
                todo = sorted(dev for c, dev in self.paths if c == cond and dev not in self.devices)
            if not todo:
                time.sleep(0.5)
                continue
            device = random.choice(todo)
            with self.lock:
                self.loading = {device}
            try:
                samples, idx = read_mat(self.paths[cond, device])
                frames = []
                for a, b in np.asarray(idx).astype(int):
                    p = samples[a - 1: b]
                    if len(p) < KEEP or not np.all(np.isfinite(p[:KEEP])):
                        continue
                    frames.append({
                        "prefix": p[:KEEP].astype(np.complex64),
                        "power": float(np.mean(np.abs(p) ** 2)),
                        "n": int(len(p)),
                    })
                del samples
                # lock onto this transmitter: the median of every packet's rough offset is a steady
                # reference, and each packet's precise offset is then resolved around it
                ref = float(np.median([coarse_cfo(f["prefix"]) for f in frames])) if frames else 0.0
                for f in frames:
                    f["coarse"] = ref
            except Exception as error:                     # an unreadable file should not stop the feed
                frames = []
                print(f"radio feed: skipped {cond} No_{device}: {error}", flush=True)
            with self.lock:
                self.loading = set()
                if gen == self.generation and frames:
                    self.devices[device] = {"frames": frames, "next": 0, "file": self.paths[cond, device].name}
                elif gen == self.generation:
                    self.devices[device] = {"frames": [], "next": 0, "file": self.paths[cond, device].name}

    # ---------- emitting ----------
    def _emit_loop(self):
        while True:
            time.sleep(random.uniform(0.6, 1.6))
            with self.lock:
                if self.paused:
                    continue
                ready = [d for d, v in self.devices.items() if v["frames"]]
                if not ready:
                    continue
                device = random.choice(ready)
                rec = self.devices[device]
                k = rec["next"] % len(rec["frames"])
                rec["next"] += 1
                frame = rec["frames"][k]
                cond, file = self.condition, rec["file"]
            m = measure(frame["prefix"], frame["power"], frame["n"], frame["coarse"])
            pre = frame["prefix"][:PREVIEW]
            scale = float(np.median(np.abs(pre)) or 1.0)
            env = None
            if self.sensors is not None:
                snap = self.sensors.snapshot()
                if snap["status"] == "live" and snap["readings"]:
                    r = snap["readings"][-1]
                    env = {k2: r.get(k2) for k2 in ("temperatureC", "humidityPct", "pressureKpa")}
            with self.lock:
                self.seq += 1
                self.packets.append({
                    "seq": self.seq,
                    "time_utc": datetime.now(timezone.utc).isoformat(timespec="milliseconds"),
                    "condition": cond,
                    "device": device,
                    "frame": k + 1,
                    "frames_in_recording": len(rec["frames"]),
                    "source_file": f"{cond}/{file}",
                    **m,
                    "env": env,
                    "preview_i": [round(float(v), 3) for v in (pre.real / scale)],
                    "preview_q": [round(float(v), 3) for v in (pre.imag / scale)],
                })

    # ---------- API ----------
    def status(self):
        with self.lock:
            total = sum(1 for c, _ in self.paths if c == self.condition)
            return {
                "source": "ZigBee_RFF recording replay",
                "condition": self.condition,
                "conditions": self.conditions,
                "devices_ready": sorted(d for d, v in self.devices.items() if v["frames"]),
                "devices_total": total,
                "loading": sorted(self.loading),
                "paused": self.paused,
                "seq": self.seq,
            }

    def since(self, seq):
        with self.lock:
            new = [p for p in self.packets if p["seq"] > seq]
        latest = new[-1] if new else None
        light = [{k: v for k, v in p.items() if not k.startswith("preview")} for p in new]
        return {**self.status(), "packets": light, "latest": latest}
