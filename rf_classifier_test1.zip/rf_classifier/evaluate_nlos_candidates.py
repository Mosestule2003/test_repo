"""Regenerate the dashboard table of indoor and outdoor NLOS candidates."""

import argparse
import json
from pathlib import Path

import numpy as np

from evaluate_preamble_gatekeeper import fit_gatekeeper, pack
from live_pair_evaluation import LiveRecordings, FEATURE_LABELS
from signal_features import DEVELOPMENT_DEVICES, INDOOR, OUTDOOR, RESERVED_DEVICES

CASES = (
    ("Indoor NLOS baseline", INDOOR, OUTDOOR, "preamble_iq", 170, 1.0),
    ("Indoor NLOS candidate", INDOOR, INDOOR, "preamble_iq", 170, 1.5),
    ("Outdoor NLOS candidate", OUTDOOR, OUTDOOR, "preamble", 320, 1.0),
    ("Outdoor NLOS wider review", OUTDOOR, OUTDOOR, "preamble", 320, 1.5),
    ("Outdoor NLOS transfer", OUTDOOR, INDOOR, "preamble", 320, 1.5),
)
PROFILE_FRAMES = np.r_[0:34, 69:135]
TEST_FRAMES = slice(160, None)
OUTPUT = Path(__file__).resolve().parent / "dashboard" / "nlos-findings.js"


def evaluate_case(recordings, target, training, feature_name, start, cutoff):
    features = {}
    for condition in dict.fromkeys((target, training)):
        devices = DEVELOPMENT_DEVICES + RESERVED_DEVICES if condition == target else DEVELOPMENT_DEVICES
        for device in devices:
            values = recordings.features(condition, device, feature_name, start)
            if condition == target and len(values) <= TEST_FRAMES.start:
                raise ValueError(f"No_{device} in {target} needs at least 161 usable frames.")
            if len(values) == 0:
                raise ValueError(f"No_{device} has no usable frames in {condition}.")
            features[condition, device, feature_name] = values

    split_rates = []
    devices = np.array(DEVELOPMENT_DEVICES)
    unseen_samples, _ = pack(features, target, feature_name, RESERVED_DEVICES, TEST_FRAMES)
    for split in range(4):
        validation_devices = devices[split::4]
        enrolled = np.setdiff1d(devices, validation_devices)
        protocol = ("nlos_candidate", training, target, target, None)
        verify, _, _ = fit_gatekeeper(
            features, feature_name, enrolled, protocol, profile_frames=PROFILE_FRAMES,
            train_on_profiles=training == target, upper_multiplier=cutoff,
        )
        known_samples, known_ids = pack(features, target, feature_name, enrolled, TEST_FRAMES)
        genuine = known_ids[:, None] == enrolled
        known = verify(known_samples)
        unseen = verify(unseen_samples)
        split_rates.append([
            known.accepted[genuine].mean(),
            unseen.accepted.any(axis=1).mean(),
            (known.accepted & ~genuine).any(axis=1).mean(),
            np.r_[known.routed.any(axis=1), unseen.routed.any(axis=1)].mean(),
        ])
    return [round(float(value) * 100, 2) for value in np.mean(split_rates, axis=0)]


def build_findings(recordings):
    rows = []
    for title, target, training, feature_name, start, cutoff in CASES:
        rates = evaluate_case(recordings, target, training, feature_name, start, cutoff)
        rows.append({
            "title": title,
            "features": FEATURE_LABELS[feature_name],
            "sample_start": start,
            "training": training.replace("_", " "),
            "cutoff": cutoff,
            "genuine": rates[0],
            "unseen": rates[1],
            "wrong_id": rates[2],
            "routed": rates[3],
        })
        print(title, rates, flush=True)
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, default=OUTPUT)
    args = parser.parse_args()
    try:
        rows = build_findings(LiveRecordings(args.data_dir.expanduser().resolve()))
        args.output.write_text(
            f"window.RF_NLOS_FINDINGS = {json.dumps(rows, indent=2)};\n", encoding="utf-8"
        )
    except (OSError, ValueError) as error:
        parser.exit(2, f"{error}\n")
    print(f"Saved benchmark data to {args.output.resolve()}")


if __name__ == "__main__":
    main()
