"""Read live sensor readings from the Arduino over USB for the dashboard.

The Arduino (MKR WiFi 1010 on the MKR IoT Carrier) prints one JSON line per reading:
    {"temperatureC":23.91,"humidityPct":36.58,"pressureKpa":101.25}
Lines that are not JSON (for example "# ready") are ignored.

ArduinoBridge reads those lines in a background thread, keeps the most recent
readings in memory for /api/environment, and appends every reading to a CSV file.
If the board is unplugged it keeps retrying, so plugging it back in resumes the feed.
"""

import csv
import json
import math
import threading
import time
from collections import deque
from datetime import datetime, timezone
from pathlib import Path

FIELDS = ("temperatureC", "humidityPct", "pressureKpa")
LIVE_SECONDS = 5          # a reading newer than this counts as live


def find_port():
    """The first port that looks like an Arduino, or None."""
    from serial.tools import list_ports

    ports = list(list_ports.comports())
    for p in ports:
        text = f"{p.device} {p.description} {p.manufacturer or ''}".lower()
        if p.vid == 0x2341 or "arduino" in text or "usbmodem" in text or "ttyacm" in text:
            return p.device
    return None


def parse(line):
    line = line.strip()
    if not line.startswith("{"):
        return None
    try:
        data = json.loads(line)
    except ValueError:
        return None
    if not isinstance(data, dict):
        return None
    out = {}
    for key in FIELDS:
        value = data.get(key)
        if isinstance(value, (int, float)) and math.isfinite(value):
            out[key] = float(value)
    return out if "temperatureC" in out else None


class ArduinoBridge:
    def __init__(self, port="auto", baud=115200, history=900, log_path=None):
        self.requested_port = port
        self.port = None
        self.baud = baud
        self.log_path = Path(log_path) if log_path else None
        self.readings = deque(maxlen=history)
        self.saved = 0
        self.error = None
        self.lock = threading.Lock()
        self.thread = threading.Thread(target=self._run, name="arduino-bridge", daemon=True)

    def start(self):
        self.thread.start()
        return self

    def _log(self, reading):
        if not self.log_path:
            return
        new = not self.log_path.exists() or self.log_path.stat().st_size == 0
        with self.log_path.open("a", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=("time_utc",) + FIELDS, extrasaction="ignore")
            if new:
                writer.writeheader()
            writer.writerow(reading)

    def _run(self):
        try:
            import serial
        except ImportError:
            with self.lock:
                self.error = "pyserial is not installed. Run: python3 -m pip install pyserial, then restart the server."
            print(f"Arduino: {self.error}", flush=True)
            return

        while True:
            port = self.requested_port if self.requested_port != "auto" else find_port()
            if not port:
                with self.lock:
                    self.port, self.error = None, "No Arduino found on USB. Plug it in; the dashboard keeps checking."
                time.sleep(2)
                continue
            try:
                with serial.Serial(port, self.baud, timeout=2) as ser:
                    with self.lock:
                        self.port, self.error = port, None
                    while True:
                        reading = parse(ser.readline().decode("utf-8", errors="ignore"))
                        if reading is None:
                            continue
                        reading["time_utc"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
                        with self.lock:
                            self.readings.append(reading)
                            self.saved += 1
                        self._log(reading)
            except (OSError, serial.SerialException) as error:
                busy = "busy" in str(error).lower() or "resource" in str(error).lower()
                with self.lock:
                    self.port = port
                    self.error = (f"{port} is in use by another program. Close the Arduino IDE Serial Monitor "
                                  f"or any logger reading it.") if busy else f"Lost the connection to {port}: {error}"
                time.sleep(2)

    def snapshot(self):
        with self.lock:
            readings = list(self.readings)
            port, error, saved = self.port, self.error, self.saved
        age = None
        if readings:
            last = datetime.fromisoformat(readings[-1]["time_utc"])
            age = (datetime.now(timezone.utc) - last).total_seconds()
        if readings and age is not None and age <= LIVE_SECONDS:
            status = "live"
        elif error:
            status = "error"
        else:
            status = "waiting"
        return {
            "status": status,
            "port": port,
            "baud": self.baud,
            "message": error,
            "age_seconds": age,
            "saved": saved,
            "log_file": str(self.log_path) if self.log_path else None,
            "readings": readings,
        }
