"use strict";

(() => {
  const byId = (id) => document.getElementById(id);
  const findings = byId("nlos-findings");
  if (findings && window.RF_NLOS_FINDINGS) {
    for (const row of window.RF_NLOS_FINDINGS) {
      const line = findings.insertRow();
      const rates = [row.genuine, row.unseen, row.wrong_id, row.routed];
      for (const value of [
        row.title, `${row.features} · ${row.sample_start}`, row.training,
        `×${row.cutoff.toFixed(1)}`, ...rates.map((rate) => `${rate.toFixed(2)}%`),
      ]) {
        line.insertCell().textContent = value;
      }
    }
  }
  if (!window.RF_DASHBOARD_DATA?.live) return;
  const status = byId("live-status");
  const result = byId("live-result");
  const settings = byId("live-configuration");
  const training = byId("live-training");
  const tier2 = byId("live-tier2");
  const names = window.RF_DASHBOARD_DATA.scenarios;
  const label = (condition) => names[condition].label;
  const displayDevice = (device) => `No_${device}`;
  const percent = (metric) => metric.total
    ? `${(metric.count * 100 / metric.total).toFixed(2)}%` : "Unavailable";
  const showCount = (metric) => metric.total ? `${metric.count} of ${metric.total}` : "";
  let activeRequest;
  let previousSelection;
  let selectedPanels;

  function showResult(data) {
    let cutoffText = `Rejection cutoff ×${data.upper_multiplier.toFixed(1)}`;
    if (data.adaptive_cutoff) {
      cutoffText = data.cutoff_validation_frames
        ? `Rejection cutoffs from ${data.cutoff_validation_frames} validation frames per device: ` +
          data.devices.map((device, index) =>
            `${displayDevice(device.id)} ×${data.device_cutoff_multipliers[index]}`).join(", ")
        : "Original rejection cutoffs · No separate cutoff-tuning frames available";
    }
    const tier2Text = data.tier2 === "claim_verifier" ? "Claim-verification SVM" : "Device-classification SVM";
    byId("live-context").textContent =
      `${tier2Text} training: ${label(data.training_condition)} · Profiles and test: ${label(data.test_condition)} · ` +
      `${data.features} at sample ${data.sample_start} · ${cutoffText} · ` +
      `${data.profile_count} profile frames per device · Test from usable frame ${data.first_test_frame}.`;
    const titles = {
      genuine_acceptance: "Genuine claims accepted",
      unseen_acceptance: "Unseen packets accepted",
      wrong_known: "Packets accepted under the wrong ID",
      svm_review: "Packets sent to the SVM",
    };
    byId("live-metrics").innerHTML = Object.entries(titles).map(([key, title]) => {
      const metric = data.metrics[key];
      return `<article class="metric"><h3>${title}</h3>
        <strong>${percent(metric)}</strong><p>${showCount(metric)}</p></article>`;
    }).join("");
    byId("live-device-rows").innerHTML = data.devices.map((device) =>
      `<tr><th scope="row">${displayDevice(device.id)}</th>` +
      [device.accepted, device.fast_pass, device.svm_accept, device.gate_rejected].map((metric) =>
        `<td>${percent(metric)} (${showCount(metric)})</td>`).join("") + "</tr>"
    ).join("");
    byId("live-wrong-claim-rows").innerHTML = data.devices.map((device) => {
      const accepted = device.wrong_claim_accepted;
      const rejected = {count: accepted.total - accepted.count, total: accepted.total};
      return `<tr><th scope="row">${displayDevice(device.id)}</th>
        <td>${displayDevice(device.wrong_claim_id)}</td>
        <td>${showCount(accepted)}</td><td>${showCount(rejected)}</td></tr>`;
    }).join("");
    byId("live-unseen").textContent = data.unseen_ids.length
      ? `Unseen test devices: ${data.unseen_ids.map(displayDevice).join(", ")}. Either selected ID can be claimed by an unseen packet.`
      : "No separate reserved devices with usable test packets are available in this condition.";
    byId("live-audit-rows").innerHTML = data.devices.map(({id, audit_recovered}) =>
      `<tr><th scope="row">${displayDevice(id)}</th><td>${
        audit_recovered.total ? `${showCount(audit_recovered)} (${percent(audit_recovered)})` : "No genuine Tier 1 rejects"
      }</td></tr>`
    ).join("");
    const wrong = data.audit_new_wrong_id_accepts;
    const unseen = data.audit_new_unseen_accepts;
    const unseenNote = unseen.total ? `${showCount(unseen)} unseen packets` : "unseen packets unavailable";
    byId("live-audit-errors").textContent =
      `Additional false accepts in the audit: ${showCount(wrong)} enrolled packets under a wrong ID · ${unseenNote}.`;
    result.hidden = false;
  }

  async function update(panels) {
    selectedPanels = panels;
    const [first, second] = panels;
    const source = training.value === "source" ? first.condition : second.condition;
    const params = new URLSearchParams({
      first: first.device, second: second.device, training: source,
      testing: second.condition, configuration: settings.value, tier2: tier2.value,
    });
    const selection = params.toString();
    if (selection === previousSelection) return;
    previousSelection = selection;
    activeRequest?.abort();
    result.hidden = true;
    if (first.device === second.device) {
      status.textContent = "Choose two different device IDs to run verification.";
      return;
    }

    const request = new AbortController();
    activeRequest = request;
    const pair = `${displayDevice(first.device)} and ${displayDevice(second.device)}`;
    status.textContent = `Testing ${pair} in ${label(second.condition)}…`;
    try {
      const response = await fetch(`/api/pair?${selection}`, { signal: request.signal });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Pair evaluation failed.");
      if (request.signal.aborted) return;
      status.textContent = `Results for ${pair} in ${label(second.condition)}.`;
      showResult(data);
    } catch (error) {
      if (request.signal.aborted) return;
      previousSelection = undefined;
      status.textContent = error.message;
    }
  }

  byId("live-options").hidden = false;
  settings.addEventListener("change", () => update(selectedPanels));
  training.addEventListener("change", () => update(selectedPanels));
  tier2.addEventListener("change", () => update(selectedPanels));
  window.updateLivePair = update;
})();
