"use strict";

const data = window.RF_DASHBOARD_DATA;
const $ = (id) => document.getElementById(id);
const formatCount = (value) => value == null ? "—" : value.toLocaleString("en-CA");
const formatPercent = (value) => `${value.toFixed(2)}%`;
const fileSize = (value) => `${(value / 1024 ** 2).toFixed(1)} MiB`;
const nameDevice = (id) => `No_${id}`;
const types = {
  iq: "I/Q time trace",
  magnitude: "Signal magnitude over samples",
  constellation: "I/Q constellation",
};
const protocols = {
  indoor_trained_outdoor_calibrated: "Indoor-trained, outdoor-calibrated",
  outdoor_fitted_later_outdoor: "Outdoor fit → later outdoor frames",
  outdoor_to_separate_indoor: "Outdoor fit → separate indoor captures",
  indoor_fitted_later_indoor: "Indoor fit → later indoor frames",
  indoor_to_separate_outdoor: "Indoor fit → separate outdoor captures",
  indoor_only_los: "LOS · Indoor-only → outdoor",
  indoor_only_nlos: "NLOS · Indoor-only → outdoor",
  outdoor_calibrated_los: "LOS · Indoor-trained, outdoor-calibrated",
  outdoor_calibrated_nlos: "NLOS · Indoor-trained, outdoor-calibrated",
};
const metricLabels = {
  genuine_accepted: "Genuine claims accepted",
  unseen_accepted_under_any_enrolled_id: "Unseen frames accepted",
  genuine_routed: "Genuine claims routed to SVM",
  wrong_enrolled_id_accepted: "Wrong enrolled ID accepted",
};
const panels = [
  { device: 13, condition: "Indoor_NLOS", preview: 0 },
  { device: 13, condition: "Outdoor_NLOS", preview: 0 },
];
let plotType = "iq";

function options(entries, current) {
  return entries.map(([value, label]) =>
    `<option value="${value}"${String(value) === String(current) ? " selected" : ""}>${label}</option>`
  ).join("");
}

function stat(label, value, className = "") {
  return `<div><dt>${label}</dt><dd class="${className}">${value}</dd></div>`;
}

function selectedRecording(panel) {
  return data.recordings.find((r) => r.device === panel.device && r.condition === panel.condition);
}

function applyPreset() {
  const [a, b] = panels;
  const preset = $("preset").value;
  const [place, visibility] = a.condition.split("_");
  if (preset === "conditions") {
    b.device = a.device;
    b.condition = `${place === "Indoor" ? "Outdoor" : "Indoor"}_${visibility}`;
  } else if (preset === "visibility") {
    b.device = a.device;
    b.condition = `${place}_${visibility === "LOS" ? "NLOS" : "LOS"}`;
  } else if (preset === "devices") {
    b.condition = a.condition;
    if (b.device === a.device) b.device = a.device === 12 ? 13 : 12;
  }
}

function resetChangedFrames(previousRecordings) {
  panels.forEach((panel, index) => {
    if (selectedRecording(panel) !== previousRecordings[index]) panel.preview = 0;
  });
}

const previewRequests = new Set();

function useAvailableRecording(panel) {
  if (!selectedRecording(panel)) {
    panel.condition = data.recordings.find((item) => item.device === panel.device).condition;
    panel.preview = 0;
  }
}

async function loadPreview(record) {
  const key = `${record.condition}/${record.device}`;
  if (!data.live || record.previews || record.previewError || previewRequests.has(key)) return;
  previewRequests.add(key);
  try {
    const query = new URLSearchParams({ condition: record.condition, device: record.device });
    const response = await fetch(`/api/recording?${query}`);
    if (!response.ok) throw new Error("Recording preview could not be loaded.");
    Object.assign(record, await response.json());
  } catch (error) {
    record.previewError = error.message;
  } finally {
    previewRequests.delete(key);
    if (panels.some((panel) => selectedRecording(panel) === record)) renderComparison();
    renderFiles();
  }
}

function renderComparison() {
  const deviceOptions = [...new Set(data.recordings.map((r) => r.device))]
    .map((device) => [device, nameDevice(device)]);
  for (const panel of panels) {
    useAvailableRecording(panel);
    loadPreview(selectedRecording(panel));
  }
  $("comparison").innerHTML = panels.map((panel, index) => {
    const rec = selectedRecording(panel);
    const conditionOptions = data.recordings.filter((item) => item.device === panel.device)
      .map((item) => [item.condition, data.scenarios[item.condition].label]);
    const previews = rec.previews || [];
    if (!previews[panel.preview]) panel.preview = 0;
    const frame = previews[panel.preview];
    return `<article class="recording">
      <h3>Recording ${index === 0 ? "A" : "B"}</h3>
      <div class="controls">
        <label class="field">Device<select data-panel="${index}" data-key="device">${options(deviceOptions, panel.device)}</select></label>
        <label class="field">Condition<select data-panel="${index}" data-key="condition">${options(conditionOptions, panel.condition)}</select></label>
        <label class="field">Frame<select data-panel="${index}" data-key="preview"${frame ? "" : " disabled"}>${options(previews.map((f, j) => [j, f.number]), panel.preview)}</select></label>
      </div>
    </article>`;
  }).join("");

  $("setup").innerHTML = panels.map((panel, index) => {
    const rec = selectedRecording(panel);
    const frame = rec.previews?.[panel.preview];
    const scenario = data.scenarios[panel.condition];
    return `<article><h3>${index === 0 ? "A" : "B"} · ${scenario.label}</h3>
      <p>${scenario.description} ${scenario.distance}.</p>
      <dl class="metadata">
        ${stat("Source file", rec.file, "mono")}
        ${stat("Indexed frames", formatCount(rec.frames))}
        ${stat("Selected frame length", frame ? `${formatCount(frame.end - frame.start + 1)} samples` : "—")}
        ${stat("Indexed capture", "1 · F5 power register")}
        ${stat("Power amplifier", rec.pa == null ? "—" : rec.pa ? "Present" : "Absent")}
        ${stat("Benchmark cohort", rec.enrolled ? "Enrolled" : "Reserved")}
      </dl>
      <p>${formatCount(rec.samples)} stored complex samples · ${fileSize(rec.size)} original file</p>
      ${frame ? `<p>Frame bounds in source file: ${formatCount(frame.start)}–${formatCount(frame.end)} (one-based, inclusive)</p>` : ""}
    </article>`;
  }).join("");

  $("plots").innerHTML = panels.map((panel, index) => {
    const rec = selectedRecording(panel);
    const frame = rec.previews?.[panel.preview];
    if (!frame) {
      const status = rec.previewError ? "Recording preview unavailable." : "Loading recording preview…";
      return `<figure class="plot awaiting-preview"><figcaption>${status}</figcaption></figure>`;
    }
    const title = `${nameDevice(rec.device)} · ${data.scenarios[rec.condition].label} · Frame ${frame.number}`;
    return `<figure class="plot"><figcaption>${title}</figcaption>
      <canvas id="plot-${index}" role="img" aria-label="${types[plotType]} for ${title}"></canvas></figure>`;
  }).join("");

  $("iq-features").innerHTML = panels.map(renderIqFeatures).join("");

  $("plot-legend").innerHTML = plotType === "iq"
    ? '<span><i class="swatch"></i>In-phase (I)</span><span><i class="swatch q"></i>Quadrature (Q)</span><span><i class="swatch window"></i>512-sample I/Q baseline window</span>'
    : plotType === "magnitude"
      ? '<span><i class="swatch"></i>Magnitude</span><span><i class="swatch window"></i>512-sample I/Q baseline window</span>'
      : '<span>Each dot is one complex sample. Both plots use the same I and Q limits.</span>';
  drawPlots();
  renderVerification();
  window.updateLivePair?.(panels);
}

function renderIqFeatures(panel, index) {
  const record = selectedRecording(panel);
  const frame = record.previews?.[panel.preview];
  const letter = index === 0 ? "A" : "B";
  const title = frame ? `Recording ${letter} · Frame ${frame.number}` : `Recording ${letter}`;
  const moments = frame?.iq_moments;
  if (!moments) {
    const message = frame || record.previewError || !data.live
      ? "I/Q features unavailable for this frame."
      : "Loading I/Q features…";
    return `<article class="feature-card"><h4>${title}</h4><p>${message}</p></article>`;
  }
  const measurements = [
    ["variance", "Variance"],
    ["skewness", "Skewness"],
    ["excess_kurtosis", "Excess kurtosis"],
  ];
  function formatValue(value) {
    if (!Number.isFinite(value)) return "—";
    return value !== 0 && Math.abs(value) < 0.00005
      ? value.toExponential(2) : value.toFixed(4);
  }
  const rows = measurements.map(([key, label]) =>
    `<tr><th scope="row">${label}</th><td>${formatValue(moments[`i_${key}`])}</td>
      <td>${formatValue(moments[`q_${key}`])}</td></tr>`
  ).join("");
  return `<article class="feature-card">
    <h4>${title}</h4>
    <table aria-label="${title} I/Q features">
      <thead><tr><th scope="col">Feature</th><th scope="col">In-phase (I)</th>
        <th scope="col">Quadrature (Q)</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>
  </article>`;
}

function drawPlots() {
  const frames = panels.map((panel) => selectedRecording(panel).previews?.[panel.preview]);
  if (frames.some((frame) => !frame)) return;
  const magnitude = frames.map((f) => f.i.map((value, j) => Math.hypot(value, f.q[j])));
  const sampleLimit = Math.max(...frames.map((f) => f.i.length), 2) - 1;
  const iqLimit = Math.max(1e-9, ...frames.flatMap((f) => [...f.i, ...f.q].map(Math.abs)));
  const magLimit = Math.max(1e-9, ...magnitude.flat());
  frames.forEach((frame, index) => {
    const canvas = $("plot-" + index);
    if (!canvas) return;
    const w = canvas.clientWidth;
    const h = canvas.clientHeight;
    if (!w || !h) return;
    const dpr = window.devicePixelRatio || 1;
    canvas.width = Math.round(w * dpr);
    canvas.height = Math.round(h * dpr);
    const ctx = canvas.getContext("2d");
    ctx.scale(dpr, dpr);
    ctx.font = "10px system-ui";
    const box = { left: 47, right: w - 11, top: 11, bottom: h - 31 };
    const scatter = plotType === "constellation";
    const isMag = plotType === "magnitude";
    if (scatter) {
      const side = Math.min(box.right - box.left, box.bottom - box.top);
      const mid = (box.left + box.right) / 2;
      box.left = mid - side / 2;
      box.right = mid + side / 2;
    }
    const xMin = scatter ? -iqLimit : 0;
    const xMax = scatter ? iqLimit : sampleLimit;
    const yMax = isMag ? magLimit : iqLimit;
    const yMin = isMag ? 0 : -yMax;
    const x = (v) => box.left + (v - xMin) / (xMax - xMin) * (box.right - box.left);
    const y = (v) => box.bottom - (v - yMin) / (yMax - yMin) * (box.bottom - box.top);
    const number = (v) => v === 0 ? "0" : Number(v.toPrecision(2)).toString();
    if (!scatter && sampleLimit > 170) {
      ctx.fillStyle = "#e1f1ec";
      ctx.fillRect(x(170), box.top, x(Math.min(682, sampleLimit)) - x(170), box.bottom - box.top);
    }
    ctx.lineWidth = 1;
    for (let j = 0; j <= 4; j++) {
      const dx = xMin + j / 4 * (xMax - xMin);
      const dy = yMin + j / 4 * (yMax - yMin);
      ctx.strokeStyle = "#dae5e7";
      ctx.beginPath();
      ctx.moveTo(x(dx), box.top);
      ctx.lineTo(x(dx), box.bottom);
      ctx.moveTo(box.left, y(dy));
      ctx.lineTo(box.right, y(dy));
      ctx.stroke();
      ctx.fillStyle = "#51656d";
      ctx.textAlign = "right";
      ctx.fillText(number(dy), box.left - 5, y(dy) + 3);
      ctx.textAlign = "center";
      ctx.fillText(scatter ? number(dx) : Math.round(dx), x(dx), box.bottom + 13);
    }
    ctx.fillText(scatter ? "I (recorded units)" : "Sample offset", (box.left + box.right) / 2, h - 4);
    ctx.save();
    ctx.translate(11, (box.bottom + box.top) / 2);
    ctx.rotate(-Math.PI / 2);
    ctx.fillText(scatter ? "Q (recorded units)" : "Recorded amplitude", 0, 0);
    ctx.restore();
    if (scatter) {
      ctx.fillStyle = "rgba(8, 126, 119, 0.25)";
      frame.i.forEach((value, j) => {
        ctx.beginPath();
        ctx.arc(x(value), y(frame.q[j]), 1.8, 0, 2 * Math.PI);
        ctx.fill();
      });
    } else {
      const traces = isMag ? [[magnitude[index], "#087e77"]] : [[frame.i, "#087e77"], [frame.q, "#4759aa"]];
      for (const [values, color] of traces) {
        ctx.strokeStyle = color;
        ctx.lineWidth = 1.15;
        ctx.beginPath();
        values.forEach((value, j) => j ? ctx.lineTo(x(j), y(value)) : ctx.moveTo(x(j), y(value)));
        ctx.stroke();
      }
    }
  });
}

function renderVerification() {
  const rows = data.results.filter((r) => r.feature_set === $("features").value && r.protocol === $("protocol").value);
  const cohortIds = data.cohort_ids || [...new Set(data.recordings.filter((r) => r.enrolled).map((r) => r.device))]
    .sort((a, b) => a - b).join("|");
  const cohort = rows.filter((r) => r.enrolled_ids === cohortIds);
  const selected = [...new Set(panels.map((panel) => panel.device))].sort((a, b) => a - b);
  const pairs = selected.length === 2
    ? rows.filter((r) => r.enrolled_ids === selected.join("|"))
    : [];
  const wholeCohort = $("results-scope").value === "cohort";
  const usePair = !wholeCohort && pairs.length > 0;
  const reference = usePair ? pairs : cohort;
  const first = reference[0];
  if (!first) {
    $("protocol-note").textContent = "No saved results for these filters.";
    $("metrics").replaceChildren();
    $("device-results").replaceChildren();
    $("los-comparison").hidden = true;
    return;
  }
  const comparison = /^(indoor_only|outdoor_calibrated)_(los|nlos)$/.exec(first.protocol);
  const separate = first.profile_condition !== first.test_condition;
  const testWindow = comparison ? "Later outdoor frames, starting with frame 70."
    : separate ? "Entire separate-condition recordings."
    : "Later frames from the same condition recordings.";
  const label = (key) => data.scenarios[first[key]].label;
  const selectedNames = selected.map(nameDevice).join(" and ");
  const scope = wholeCohort ? "All 12 enrolled devices"
    : usePair ? `Pair test for ${selectedNames}`
    : `Individual results for ${selectedNames} in the full cohort`;
  const pairNote = !wholeCohort && !usePair && selected.length === 2
    ? " No dedicated pair test is available for this selection and evaluation."
    : "";
  $("protocol-note").textContent = `${scope}. Training: ${label("training_condition")} · Profiles and calibration: ${label("profile_condition")} · Test: ${label("test_condition")}. ${testWindow}${pairNote}`;
  const visibleDevices = reference.filter((r) => r.device_id &&
    (wholeCohort || selected.includes(Number(r.device_id))));
  const cards = wholeCohort || usePair
    ? Object.entries(metricLabels).flatMap(([key, title]) => {
      const row = reference.find((r) => !r.device_id && r.metric === key);
      return row ? [[row, title]] : [];
    })
    : visibleDevices.flatMap((row) => {
      const title = metricLabels[row.metric];
      return title ? [[row, `${nameDevice(row.device_id)} · ${title}`]] : [];
    });
  $("metrics").innerHTML = cards.map(([row, title]) =>
    `<article class="metric"><h3>${title}</h3>
      <strong>${formatPercent(row.rate_percent)}</strong><p>${formatCount(row.count)} of ${formatCount(row.total)}</p></article>`
  ).join("") || '<p class="fine-print">No individual metrics for these devices.</p>';
  $("device-results").innerHTML = visibleDevices.filter((r) =>
      ["genuine_accepted", "unseen_accepted_under_any_enrolled_id"].includes(r.metric))
    .map((r) => `<tr><td>${nameDevice(r.device_id)}</td><td>${r.metric === "genuine_accepted" ? "Enrolled" : "Unseen"}</td>
      <td>${formatCount(r.count)} of ${formatCount(r.total)}</td><td>${formatPercent(r.rate_percent)}</td></tr>`).join("");
  renderLOSComparison(comparison?.[1], cards);
}

function renderLOSComparison(mode, cards) {
  const section = $("los-comparison");
  section.hidden = true;
  if (!mode) return;
  const results = data.results.filter((r) => r.feature_set === $("features").value &&
    (r.protocol === `${mode}_los` || r.protocol === `${mode}_nlos`));
  const value = (r) => `${formatPercent(r.rate_percent)} (${formatCount(r.count)} of ${formatCount(r.total)})`;
  const matches = cards.flatMap(([row, title]) => {
    const find = (visibility) => results.find((r) => r.protocol === `${mode}_${visibility}` &&
      r.enrolled_ids === row.enrolled_ids && r.device_id === row.device_id && r.metric === row.metric);
    const los = find("los");
    const nlos = find("nlos");
    if (!los || !nlos) return [];
    const delta = los.rate_percent - nlos.rate_percent;
    return [`<tr><td>${title}</td><td>${value(los)}</td><td>${value(nlos)}</td>
      <td>${delta > 0 ? "+" : ""}${delta.toFixed(2)} pp</td></tr>`];
  });
  $("los-comparison-rows").innerHTML = matches.join("");
  section.hidden = matches.length === 0;
}

function renderFiles() {
  const query = $("file-filter").value.trim().toLowerCase();
  const matches = data.recordings.filter((r) => `${r.device} ${r.file} ${data.scenarios[r.condition].label}`.toLowerCase().includes(query));
  $("file-rows").innerHTML = matches.map((r) => `<tr>
    <td>${nameDevice(r.device)}</td><td>${data.scenarios[r.condition].label}</td><td class="mono">${r.file}</td>
    <td>${formatCount(r.frames)}</td><td>${fileSize(r.size)}</td>
    <td><button data-slot="0" data-device="${r.device}" data-condition="${r.condition}" aria-label="Compare ${r.file} in panel A">A</button>
    <button data-slot="1" data-device="${r.device}" data-condition="${r.condition}" aria-label="Compare ${r.file} in panel B">B</button></td>
  </tr>`).join("") || '<tr><td colspan="6">No recordings match this filter.</td></tr>';
}

if (!data) {
  $("load-error").hidden = false;
} else {
  $("dataset-counts").innerHTML = [
    ["Devices", new Set(data.recordings.map((r) => r.device)).size],
    ["Conditions", Object.keys(data.scenarios).length],
    ["Recordings", data.recordings.length],
  ].map(([label, value]) => `<div><dt>${label}</dt><dd>${value}</dd></div>`).join("");
  const availableProtocols = new Set(data.results.map((r) => r.protocol));
  const protocolOptions = Object.entries(protocols).filter(([key]) => availableProtocols.has(key));
  $("protocol").innerHTML = options(protocolOptions, protocolOptions[0]?.[0]);
  const hasLOS = "Indoor_LOS" in data.scenarios && "Outdoor_LOS" in data.scenarios;
  $("visibility-preset").hidden = !hasLOS;
  $("los-import-note").hidden = hasLOS || data.live;
  if (data.live) {
    const preferredA = data.recordings.find((item) => item.device === 13 && item.condition === "Indoor_NLOS");
    const first = preferredA || data.recordings[0];
    const preferredB = data.recordings.find((item) => item.device === 14 && item.condition === "Outdoor_NLOS");
    const second = preferredB || data.recordings.find((item) => item.device !== first.device) || first;
    Object.assign(panels[0], { device: first.device, condition: first.condition });
    Object.assign(panels[1], { device: second.device, condition: second.condition });
    $("preset").value = "custom";
  }
  $("preset").addEventListener("change", () => {
    const previousRecordings = panels.map(selectedRecording);
    applyPreset();
    resetChangedFrames(previousRecordings);
    renderComparison();
  });
  $("comparison").addEventListener("change", (event) => {
    const { panel, key } = event.target.dataset;
    if (!key) return;
    const previousRecordings = panels.map(selectedRecording);
    panels[panel][key] = key === "condition" ? event.target.value : Number(event.target.value);
    if (key !== "preview") {
      if (panel === "1") $("preset").value = "custom";
      applyPreset();
      resetChangedFrames(previousRecordings);
    }
    renderComparison();
    $("comparison").querySelector(`[data-panel="${panel}"][data-key="${key}"]`)?.focus();
  });
  document.querySelectorAll("[data-plot]").forEach((button) => {
    button.addEventListener("click", () => {
      plotType = button.dataset.plot;
      document.querySelectorAll("[data-plot]").forEach((item) => item.setAttribute("aria-pressed", String(item === button)));
      renderComparison();
    });
  });
  $("features").addEventListener("change", renderVerification);
  $("protocol").addEventListener("change", renderVerification);
  $("results-scope").addEventListener("change", renderVerification);
  $("file-filter").addEventListener("input", renderFiles);
  $("file-rows").addEventListener("click", (event) => {
    const { slot, device, condition } = event.target.dataset;
    if (slot === undefined) return;
    panels[slot] = { device: Number(device), condition, preview: 0 };
    $("preset").value = "custom";
    renderComparison();
    $("signals").scrollIntoView();
  });
  window.addEventListener("resize", drawPlots);
  renderComparison();
  renderFiles();
}
