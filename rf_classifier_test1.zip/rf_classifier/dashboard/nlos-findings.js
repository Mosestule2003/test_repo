window.RF_NLOS_FINDINGS = [
  {
    "title": "Indoor NLOS baseline",
    "features": "Preamble + I/Q statistics",
    "sample_start": 170,
    "training": "Outdoor NLOS",
    "cutoff": 1.0,
    "genuine": 65.1,
    "unseen": 0.0,
    "wrong_id": 3.13,
    "routed": 10.84
  },
  {
    "title": "Indoor NLOS candidate",
    "features": "Preamble + I/Q statistics",
    "sample_start": 170,
    "training": "Indoor NLOS",
    "cutoff": 1.5,
    "genuine": 79.63,
    "unseen": 0.96,
    "wrong_id": 5.33,
    "routed": 17.71
  },
  {
    "title": "Outdoor NLOS candidate",
    "features": "Preamble",
    "sample_start": 320,
    "training": "Outdoor NLOS",
    "cutoff": 1.0,
    "genuine": 80.56,
    "unseen": 0.75,
    "wrong_id": 3.25,
    "routed": 19.59
  },
  {
    "title": "Outdoor NLOS wider review",
    "features": "Preamble",
    "sample_start": 320,
    "training": "Outdoor NLOS",
    "cutoff": 1.5,
    "genuine": 89.05,
    "unseen": 3.32,
    "wrong_id": 3.33,
    "routed": 28.28
  },
  {
    "title": "Outdoor NLOS transfer",
    "features": "Preamble",
    "sample_start": 320,
    "training": "Indoor NLOS",
    "cutoff": 1.5,
    "genuine": 80.99,
    "unseen": 1.01,
    "wrong_id": 7.51,
    "routed": 28.28
  }
];
