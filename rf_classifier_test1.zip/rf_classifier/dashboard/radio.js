/* Live-style radio feed: polls /api/radio and shows packets with the environment at receipt. */
(function () {
  const POLL_MS = 700;
  const CFO_WINDOW_S = 120;
  const ROWS = 14;
  const $ = (id) => document.getElementById(id);
  if (!$("radio-feed")) return;

  const status = $("radio-status"), source = $("radio-source"), help = $("radio-help"),
    condSel = $("radio-condition"), pauseBtn = $("radio-pause"), metrics = $("radio-metrics"),
    rows = $("radio-rows"), wave = $("radio-wave"), waveCap = $("radio-wave-cap"), cfoCanvas = $("radio-cfo"),
    controls = $("radio-controls");

  const setStatus = (state, text) => { status.dataset.state = state; status.textContent = text; };
  if (location.protocol === "file:") { setStatus("off", "Server needed"); help.hidden = false; controls.hidden = true; return; }

  const css = () => getComputedStyle(document.documentElement);
  const color = (name, fallback) => css().getPropertyValue(name).trim() || fallback;
  const devColor = (d) => `hsl(${(d * 47) % 360} 62% 42%)`;
  const label = (c) => c.replace(/_/g, " ").replace("NLOS", "NLOS").replace(/^(\w+) (\w+)$/, "$1 $2");

  const cards = {};
  [["count", "Packets received"], ["rate", "Packets per minute"], ["devices", "Transmitters heard"], ["last", "Last packet from"]]
    .forEach(([k, t]) => {
      const a = document.createElement("article"); a.className = "metric";
      a.innerHTML = "<h3></h3><strong>—</strong><p></p>"; a.querySelector("h3").textContent = t;
      metrics.appendChild(a); cards[k] = a;
    });
  const setCard = (k, v, sub) => { cards[k].querySelector("strong").textContent = v; cards[k].querySelector("p").textContent = sub || ""; };

  let lastSeq = 0, packets = [], latest = null, conditionsBuilt = false, paused = false, total = 0;

  function sizeCanvas(c) {
    const dpr = window.devicePixelRatio || 1, w = c.clientWidth, h = c.clientHeight;
    c.width = Math.round(w * dpr); c.height = Math.round(h * dpr);
    const ctx = c.getContext("2d"); ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, w, h);
    ctx.font = "11px system-ui, sans-serif";
    return [ctx, w, h];
  }

  function drawWave() {
    const [ctx, w, h] = sizeCanvas(wave);
    if (!w) return;
    const muted = color("--muted", "#51656d"), line = color("--line", "#dce4e6");
    if (!latest) { ctx.fillStyle = muted; ctx.fillText("Waiting for the first packet…", 8, h / 2); return; }
    const I = latest.preview_i, Q = latest.preview_q;
    const lim = Math.max(1.2, ...I.map(Math.abs), ...Q.map(Math.abs));
    const ml = 34, mr = 8, mt = 8, mb = 20;
    const x = (i) => ml + (i / (I.length - 1)) * (w - ml - mr);
    const y = (v) => mt + (1 - (v + lim) / (2 * lim)) * (h - mt - mb);
    ctx.strokeStyle = line; ctx.fillStyle = muted; ctx.lineWidth = 1;
    [-1, 0, 1].forEach((v) => { ctx.beginPath(); ctx.moveTo(ml, y(v)); ctx.lineTo(w - mr, y(v)); ctx.stroke();
      ctx.textAlign = "right"; ctx.textBaseline = "middle"; ctx.fillText(String(v), ml - 6, y(v)); });
    ctx.textBaseline = "alphabetic";
    [0, 20, 40, 60, 76.8].forEach((us) => { ctx.textAlign = us ? (us > 70 ? "right" : "center") : "left";
      ctx.fillText(us > 70 ? "76.8 µs" : `${us}`, x(us * 10), h - 5); });
    [[I, color("--teal", "#087e77")], [Q, color("--blue", "#4759aa")]].forEach(([s, c]) => {
      ctx.strokeStyle = c; ctx.lineWidth = 1.1; ctx.beginPath();
      s.forEach((v, i) => (i ? ctx.lineTo(x(i), y(v)) : ctx.moveTo(x(i), y(v)))); ctx.stroke();
    });
  }

  function drawCfo() {
    const [ctx, w, h] = sizeCanvas(cfoCanvas);
    if (!w) return;
    const muted = color("--muted", "#51656d"), line = color("--line", "#dce4e6");
    const now = Date.now(), t0 = now - CFO_WINDOW_S * 1000;
    const pts = packets.filter((p) => p.t >= t0);
    if (pts.length < 1) { ctx.fillStyle = muted; ctx.fillText("Waiting for packets…", 8, h / 2); return; }
    let lo = Math.min(...pts.map((p) => p.cfo_hz)) / 1000, hi = Math.max(...pts.map((p) => p.cfo_hz)) / 1000;
    const pad = Math.max((hi - lo) * 0.1, 2); lo -= pad; hi += pad;
    const ticks = [hi, (hi + lo) / 2, lo];
    ctx.textAlign = "right";
    const ml = Math.max(...ticks.map((t) => ctx.measureText(t.toFixed(0)).width)) + 10, mr = 8, mt = 8, mb = 20;
    const x = (t) => ml + ((t - t0) / (now - t0)) * (w - ml - mr);
    const y = (v) => mt + (1 - (v - lo) / (hi - lo)) * (h - mt - mb);
    ctx.strokeStyle = line; ctx.fillStyle = muted; ctx.lineWidth = 1;
    ticks.forEach((v) => { ctx.beginPath(); ctx.moveTo(ml, y(v)); ctx.lineTo(w - mr, y(v)); ctx.stroke();
      ctx.textBaseline = "middle"; ctx.fillText(v.toFixed(0), ml - 6, y(v)); });
    ctx.textBaseline = "alphabetic"; ctx.textAlign = "left"; ctx.fillText(`−${CFO_WINDOW_S} s`, ml, h - 5);
    ctx.textAlign = "right"; ctx.fillText("now (kHz)", w - mr, h - 5);
    pts.forEach((p) => { ctx.fillStyle = devColor(p.device); ctx.beginPath(); ctx.arc(x(p.t), y(p.cfo_hz / 1000), 3.4, 0, 7); ctx.fill(); });
  }

  const fmt = (v, d) => (v == null ? "—" : Number(v).toFixed(d));
  function renderRows() {
    rows.replaceChildren(...packets.slice(-ROWS).reverse().map((p) => {
      const tr = document.createElement("tr");
      const e = p.env || {};
      const cells = [new Date(p.t).toLocaleTimeString(), `No_${p.device}`, `${p.frame} / ${p.frames_in_recording}`,
        fmt(p.power_dbfs, 1), fmt(p.snr_db, 1), fmt(p.cfo_hz / 1000, 2),
        fmt(e.temperatureC, 2), fmt(e.humidityPct, 1), fmt(e.pressureKpa, 2)];
      cells.forEach((c, i) => {
        const td = document.createElement("td"); td.textContent = c;
        if (i === 1) { const sw = document.createElement("span"); sw.className = "radio-dot"; sw.style.background = devColor(p.device); td.prepend(sw); }
        if (i >= 3) td.className = "num";
        if (i >= 6) td.classList.add("env-cell");
        tr.appendChild(td);
      });
      if (p.seq === (latest && latest.seq)) tr.className = "radio-new";
      return tr;
    }));
  }

  function renderMeta(d) {
    if (!conditionsBuilt && d.conditions) {
      condSel.replaceChildren(...d.conditions.map((c) => new Option(label(c), c)));
      conditionsBuilt = true;
    }
    if (d.condition && document.activeElement !== condSel) condSel.value = d.condition;
    paused = !!d.paused; pauseBtn.textContent = paused ? "Resume" : "Pause";
    pauseBtn.setAttribute("aria-pressed", String(paused));
    const ready = (d.devices_ready || []).length;
    if (!d.source) { setStatus("off", "Not running"); help.hidden = false; controls.hidden = true; return; }
    help.hidden = true; controls.hidden = false;
    if (paused) setStatus("waiting", "Paused");
    else if (!ready) setStatus("waiting", `Tuning in · loading ${label(d.condition)}`);
    else setStatus("live", `Receiving · ${label(d.condition)}`);
    const loadNote = ready < d.devices_total ? ` · ${ready} of ${d.devices_total} transmitters loaded` : "";
    source.textContent = `Source: ${d.source} (no SDR attached)${loadNote}` +
      (latest ? ` · last packet from ${latest.source_file}, frame ${latest.frame}` : "");
  }

  function renderAll(d) {
    renderMeta(d);
    const now = Date.now();
    const lastMin = packets.filter((p) => p.t >= now - 60000);
    setCard("count", total.toLocaleString(), "since this page opened");
    setCard("rate", String(lastMin.length), "in the last 60 s");
    setCard("devices", String(new Set(lastMin.map((p) => p.device)).size), "in the last 60 s");
    if (latest) setCard("last", `No_${latest.device}`,
      `${fmt(latest.power_dbfs, 1)} dBFS · ${fmt(latest.snr_db, 1)} dB · ${fmt(latest.cfo_hz / 1000, 1)} kHz offset`);
    waveCap.textContent = latest ? `Latest packet: No_${latest.device}, first 76.8 µs (I teal, Q blue)` : "Latest packet";
    drawWave(); drawCfo(); renderRows();
  }

  let lastData = null;
  async function poll() {
    try {
      const res = await fetch(`/api/radio?since=${lastSeq}`, { cache: "no-store" });
      const d = await res.json();
      if (d.packets && d.packets.length) {
        if (lastSeq === 0) d.packets = d.packets.slice(-1);       // start the page's feed fresh
        d.packets.forEach((p) => packets.push({ ...p, t: Date.parse(p.time_utc) }));
        total += d.packets.length;
        packets = packets.slice(-400);
        lastSeq = d.seq;
      } else if (d.seq != null && lastSeq === 0) lastSeq = d.seq;
      if (d.latest) latest = d.latest;
      lastData = d;
      renderAll(d);
    } catch (e) {
      setStatus("error", "Server not responding");
    }
  }

  condSel.addEventListener("change", async () => {
    await fetch(`/api/radio/config?condition=${encodeURIComponent(condSel.value)}`, { cache: "no-store" });
    packets = []; latest = null; total = 0; poll();
  });
  pauseBtn.addEventListener("click", async () => {
    await fetch(`/api/radio/config?paused=${paused ? 0 : 1}`, { cache: "no-store" }); poll();
  });
  window.addEventListener("resize", () => lastData && renderAll(lastData));
  poll();
  setInterval(poll, POLL_MS);
})();
