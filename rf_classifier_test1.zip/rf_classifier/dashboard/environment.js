/* Live Arduino sensor panel: polls /api/environment and draws the latest readings. */
(function () {
  const POLL_MS = 1500;
  const WINDOW_MIN = 10;                     // minutes shown in the charts
  const SERIES = [
    { key: "temperatureC", label: "Temperature", unit: "°C", digits: 2, color: "--amber" },
    { key: "humidityPct", label: "Humidity", unit: "%", digits: 1, color: "--teal" },
    { key: "pressureKpa", label: "Pressure", unit: "kPa", digits: 2, color: "--blue" },
  ];
  const $ = (id) => document.getElementById(id);
  const section = $("sensors");
  if (!section) return;

  const status = $("sensor-status"), help = $("sensor-help"), metrics = $("sensor-metrics"),
    plots = $("sensor-plots"), logNote = $("sensor-log");

  if (location.protocol === "file:") {
    setStatus("off", "Server needed");
    help.hidden = false;
    return;
  }

  // build the cards and charts once
  const cards = {}, canvases = {};
  SERIES.forEach((s) => {
    const card = document.createElement("article");
    card.className = "metric";
    card.innerHTML = `<h3></h3><strong>—</strong><p></p>`;
    card.querySelector("h3").textContent = `${s.label} (${s.unit})`;
    metrics.appendChild(card);
    cards[s.key] = card;

    const fig = document.createElement("figure");
    fig.className = "plot";
    const cap = document.createElement("figcaption");
    cap.textContent = `${s.label}, last ${WINDOW_MIN} minutes`;
    const canvas = document.createElement("canvas");
    canvas.setAttribute("role", "img");
    canvas.setAttribute("aria-label", `${s.label} over the last ${WINDOW_MIN} minutes`);
    fig.append(cap, canvas);
    plots.appendChild(fig);
    canvases[s.key] = canvas;
  });
  const countCard = document.createElement("article");
  countCard.className = "metric";
  countCard.innerHTML = `<h3>Readings saved</h3><strong>—</strong><p></p>`;
  metrics.appendChild(countCard);

  let last = null;

  function setStatus(kind, text) {
    status.textContent = text;
    status.dataset.state = kind;
  }

  function fmt(v, d) { return v == null ? "—" : v.toFixed(d); }

  function draw(canvas, pts, s) {
    const dpr = window.devicePixelRatio || 1;
    const w = canvas.clientWidth, h = canvas.clientHeight;
    if (!w || !h) return;
    canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
    const ctx = canvas.getContext("2d");
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);
    const css = getComputedStyle(document.documentElement);
    const color = css.getPropertyValue(s.color).trim() || "#087e77";
    const muted = css.getPropertyValue("--muted").trim() || "#51656d";
    const line = css.getPropertyValue("--line").trim() || "#dce4e6";
    ctx.font = "11px system-ui, sans-serif";
    if (pts.length < 2) {
      ctx.fillStyle = muted;
      ctx.fillText("Waiting for readings…", 8, h / 2);
      return;
    }
    const now = Date.now(), t0 = now - WINDOW_MIN * 60000;
    let lo = Math.min(...pts.map((p) => p.v)), hi = Math.max(...pts.map((p) => p.v));
    const pad = Math.max((hi - lo) * 0.15, s.key === "pressureKpa" ? 0.05 : 0.2);
    lo -= pad; hi += pad;
    const labels = [hi, (hi + lo) / 2, lo].map((v) => v.toFixed(s.digits));
    const ml = Math.max(...labels.map((l) => ctx.measureText(l).width)) + 10, mr = 8, mt = 8, mb = 20;
    const x = (t) => ml + ((t - t0) / (now - t0)) * (w - ml - mr);
    const y = (v) => mt + (1 - (v - lo) / (hi - lo)) * (h - mt - mb);
    ctx.strokeStyle = line; ctx.lineWidth = 1; ctx.fillStyle = muted;
    labels.forEach((l, i) => {
      const yy = mt + (i / 2) * (h - mt - mb);
      ctx.beginPath(); ctx.moveTo(ml, yy); ctx.lineTo(w - mr, yy); ctx.stroke();
      ctx.textAlign = "right"; ctx.textBaseline = "middle"; ctx.fillText(l, ml - 6, yy);
    });
    ctx.textAlign = "left"; ctx.textBaseline = "alphabetic";
    ctx.fillText(`−${WINDOW_MIN} min`, ml, h - 5);
    ctx.textAlign = "right"; ctx.fillText("now", w - mr, h - 5);
    ctx.strokeStyle = color; ctx.lineWidth = 1.8; ctx.beginPath();
    pts.forEach((p, i) => (i ? ctx.lineTo(x(p.t), y(p.v)) : ctx.moveTo(x(p.t), y(p.v))));
    ctx.stroke();
    const end = pts[pts.length - 1];
    ctx.fillStyle = color; ctx.beginPath(); ctx.arc(x(end.t), y(end.v), 3.2, 0, Math.PI * 2); ctx.fill();
  }

  function render(data) {
    last = data;
    const readings = (data.readings || []).map((r) => ({ ...r, t: Date.parse(r.time_utc) }));
    const cutoff = Date.now() - WINDOW_MIN * 60000;
    const recent = readings.filter((r) => r.t >= cutoff);
    const latest = readings[readings.length - 1];

    if (data.status === "live") setStatus("live", `Live · ${data.port}`);
    else if (data.status === "off") setStatus("off", "Not connected");
    else if (data.status === "error") setStatus("error", "Connection problem");
    else setStatus("waiting", "Waiting for the Arduino");
    help.hidden = data.status !== "off";
    logNote.textContent = data.message ? data.message
      : data.log_file ? `Every reading is also saved to ${data.log_file}.` : "";

    SERIES.forEach((s) => {
      const card = cards[s.key];
      card.querySelector("strong").textContent = latest ? fmt(latest[s.key], s.digits) : "—";
      const first = recent.find((r) => r[s.key] != null);
      const p = card.querySelector("p");
      if (latest && first && latest !== first) {
        const d = latest[s.key] - first[s.key], mins = Math.max(1, Math.round((latest.t - first.t) / 60000));
        p.textContent = `${d >= 0 ? "+" : "−"}${Math.abs(d).toFixed(s.digits)} ${s.unit} over ${mins} min`;
      } else p.textContent = latest ? "First reading" : "No readings yet";
      draw(canvases[s.key], recent.filter((r) => r[s.key] != null).map((r) => ({ t: r.t, v: r[s.key] })), s);
    });
    countCard.querySelector("strong").textContent = data.saved != null ? data.saved.toLocaleString() : "—";
    countCard.querySelector("p").textContent = data.age_seconds != null
      ? `Last reading ${Math.max(0, Math.round(data.age_seconds))} s ago` : "Since the server started";
  }

  async function poll() {
    try {
      const res = await fetch("/api/environment", { cache: "no-store" });
      if (!res.ok) throw new Error(res.statusText);
      render(await res.json());
    } catch (e) {
      setStatus("error", "Server not responding");
      logNote.textContent = "The dashboard server stopped. Start serve_dashboard.py again.";
    }
  }

  window.addEventListener("resize", () => last && render(last));
  poll();
  setInterval(poll, POLL_MS);
})();
