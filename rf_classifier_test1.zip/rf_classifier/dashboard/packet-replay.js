"use strict";

(() => {
  const data = window.RF_PACKET_REPLAYS;
  const byId = (id) => document.getElementById(id);
  if (!data?.runs.length) {
    byId("packet-unavailable").hidden = false;
    return;
  }

  const run = byId("packet-run");
  const sender = byId("packet-sender");
  const claim = byId("packet-claim");
  const frame = byId("packet-frame");
  const next = byId("packet-next");
  const outcome = byId("packet-outcome");
  const source = byId("packet-source");
  const formatDevice = (id) => `No_${id}`;
  const displayCondition = (condition) => condition.replace("_", " ");
  const displayDistance = (value) => Number(value.toPrecision(5)).toLocaleString("en-CA", {
    maximumSignificantDigits: 5,
  });
  const active = () => data.runs[Number(run.value)];
  const packets = () => active().packets[sender.value];
  const claimIndex = () => Number(claim.value);

  function fill(select, entries, value) {
    select.replaceChildren(...entries.map(([key, label]) => new Option(label, key)));
    select.value = value;
  }

  function clearOutcome() {
    outcome.textContent = "";
    const recording = `${active().test}/${formatDevice(sender.value)}_F5_1.mat`;
    source.textContent = `Source ${recording} · Frame ${frame.value} · Training ${displayCondition(active().training)} · Profiles and calibration ${displayCondition(active().profile)}`;
  }

  function updateSummary() {
    const index = claimIndex();
    const routes = packets().filter((packet) => packet[3].includes(index));
    const svmBlocked = routes.filter((packet) => !packet[4].includes(index)).length;
    const falseAccepts = packets().filter((packet) => packet[4].includes(index)).length;
    const fastAccepted = falseAccepts - (routes.length - svmBlocked);
    const gateBlocked = packets().length - routes.length - fastAccepted;
    next.disabled = routes.length === 0;
    const review = routes.length
      ? `The calibrated SVM blocked ${svmBlocked} of ${routes.length} routed frames (${(100 * svmBlocked / routes.length).toFixed(1)}%).`
      : "No frames for this claim reached the SVM.";
    byId("packet-reliability").textContent =
      `Across ${packets().length} held-out frames for this sender and claimed ID, Mahalanobis blocked ${gateBlocked} and fast-passed ${fastAccepted}. ${review} The full verifier falsely accepted ${falseAccepts} of ${packets().length}.`;
  }

  function updateFrames(preferred) {
    const rows = packets();
    fill(frame, rows.map(([number]) => [number, number]), preferred ?? rows[0][0]);
    clearOutcome();
    updateSummary();
  }

  function updateCohort() {
    const rows = Object.values(active().packets).flat();
    let routed = 0;
    let blocked = 0;
    let falseAccepts = 0;
    for (const [, , , reviewed, accepted] of rows) {
      routed += reviewed.length;
      blocked += reviewed.filter((index) => !accepted.includes(index)).length;
      falseAccepts += Number(accepted.length > 0);
    }
    const review = routed
      ? `The calibrated SVM blocked ${blocked} of ${routed} routed claims (${(100 * blocked / routed).toFixed(1)}%).`
      : "No claims reached the SVM.";
    byId("packet-cohort").textContent =
      `${review} The full verifier accepted ${falseAccepts} of ${rows.length} unseen frames under at least one enrolled ID.`;
  }

  function updateSenders(preferred, preferredFrame) {
    const ids = Object.keys(active().packets);
    fill(sender, ids.map((id) => [id, formatDevice(id)]), preferred ?? ids[0]);
    updateFrames(preferredFrame);
    updateCohort();
  }

  function send() {
    const [number, svmId, distances, routed, accepted] = packets().find((packet) => packet[0] === Number(frame.value));
    const index = claimIndex();
    const [low, high] = active().thresholds[index];
    const wasRouted = routed.includes(index);
    const passed = accepted.includes(index);
    const tier1 = wasRouted ? "Routed to SVM" : passed ? "Fast-pass accepted" : "Rejected at gate";
    const tier2 = wasRouted ? passed ? "Claim matched" : "Claim rejected" : "Skipped for this claim";
    const tier2Detail = wasRouted ? `Calibrated SVM chose ${formatDevice(svmId)}.` :
      passed ? "Tier 1 accepted this claim." : "Tier 1 rejected this claim.";
    outcome.innerHTML = `<div class="packet-path">
      <article class="packet-step"><h3>Tier 1 · Mahalanobis</h3><strong>${tier1}</strong>
      <p class="fine-print">Squared distance ${displayDistance(distances[index])} · Fast-pass threshold ${displayDistance(low)} · Reject above ${displayDistance(high)}</p></article>
      <article class="packet-step"><h3>Tier 2 · SVM</h3><strong>${tier2}</strong>
      <p class="fine-print">${tier2Detail}</p></article>
      <article class="packet-step" data-verdict="${passed ? "accepted" : "blocked"}"><h3>Final verdict</h3>
      <strong>${passed ? "False acceptance" : "Unknown sender blocked"}</strong>
      <p class="fine-print">${formatDevice(sender.value)} sent frame ${number} claiming ${formatDevice(data.enrolled[index])}.</p></article>
    </div>`;
  }

  fill(run, data.runs.map((item, index) => {
    const mode = item.training === item.profile ? "Indoor only" : "Outdoor-calibrated";
    const features = item.features === "preamble" ? "Preamble" : "Normalized I/Q + phase";
    return [index, `${displayCondition(item.test)} · ${mode} · ${features}`];
  }), 0);
  let initialSender;
  let initialFrame;
  let initialClaim = 0;
  for (const [id, rows] of Object.entries(active().packets)) {
    const example = rows.find((packet) => packet[3].some((index) => !packet[4].includes(index)));
    if (example) {
      initialSender = id;
      initialFrame = example[0];
      initialClaim = example[3].find((index) => !example[4].includes(index));
      break;
    }
  }
  fill(claim, data.enrolled.map((id, index) => [index, formatDevice(id)]), initialClaim);
  updateSenders(initialSender, initialFrame);
  run.addEventListener("change", () => updateSenders(sender.value));
  sender.addEventListener("change", () => updateFrames());
  claim.addEventListener("change", () => {
    clearOutcome();
    updateSummary();
  });
  frame.addEventListener("change", clearOutcome);
  byId("packet-send").addEventListener("click", send);
  next.addEventListener("click", () => {
    const rows = packets();
    const after = rows.findIndex((packet) => packet[0] === Number(frame.value)) + 1;
    const routed = [...rows.slice(after), ...rows.slice(0, after)]
      .find((packet) => packet[3].includes(claimIndex()));
    if (routed) {
      frame.value = routed[0];
      clearOutcome();
      send();
    }
  });
  byId("packet-controls").hidden = false;
})();
