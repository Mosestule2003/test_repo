import numpy as np
import pandas as pd

from sklearn.metrics import accuracy_score, recall_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC


def load_features(scenario):
    recordings = []

    for device_number in (10, 11):
        source_file = f"No_{device_number}_F5_1.mat"
        filename = f"{scenario}_No_{device_number}_F5_1_iq_features.csv"
        recording = pd.read_csv(filename)

        if not recording["scenario"].eq(scenario).all():
            raise ValueError(f"{filename} contains rows outside {scenario}")
        if not recording["source_file"].eq(source_file).all():
            raise ValueError(f"{filename} contains rows from another recording")

        recordings.append(recording)

    combined = pd.concat(recordings, ignore_index=True)
    table = combined.pivot(
        index=["source_file", "frame"],
        columns="window",
        values=["mean", "variance", "skewness", "kurtosis", "phase_sin", "phase_cos"],
    )
    table.columns = [
        f"{window}_{statistic}" for statistic, window in table.columns
    ]

    # The steady-window mean is approximately 1 after normalization.
    table = table.drop(columns="steady_mean")
    valid_table = table.replace([np.inf, -np.inf], np.nan).dropna()
    labels = valid_table.index.get_level_values("source_file")

    for device_number in (10, 11):
        if f"No_{device_number}_F5_1.mat" not in labels:
            raise ValueError(f"{scenario}: no valid frames for device {device_number}")

    print(f"{scenario}: excluded {len(table) - len(valid_table)} frames")
    return valid_table, labels


training_scenario = "Indoor_NLOS"
test_scenario = "Outdoor_NLOS"
device_labels = ["No_10_F5_1.mat", "No_11_F5_1.mat"]

X_train, y_train = load_features(training_scenario)
X_test, y_test = load_features(test_scenario)
X_test = X_test[X_train.columns]

model = make_pipeline(
    StandardScaler(),
    SVC(kernel="rbf", C=1.0, gamma="scale"),
)
model.fit(X_train, y_train)
predictions = model.predict(X_test)

recall_10, recall_11 = recall_score(
    y_test,
    predictions,
    labels=device_labels,
    average=None,
)

print(f"\nTraining on {training_scenario} ({len(X_train)} frames)")
print(f"Testing on {test_scenario} ({len(X_test)} frames)")
print(f"Accuracy: {accuracy_score(y_test, predictions):.2%}")
print(f"No_10 recall: {recall_10:.2%}")
print(f"No_11 recall: {recall_11:.2%}")
