"""Capture or import I/Q recordings and optionally extract signal features.

Simulation generates test data for storage and control flow.
"""
import argparse
import csv
import pickle
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

FIELDS = [
    "capture_id", "time_utc", "device_id", "label_status", "channel",
    "channel_frequency_hz", "sample_rate_hz", "gain_db", "sample_count",
    "iq_file", "start_trame", "End_trame",
]
FEATURE_FIELDS = [
    "capture_id", "device_id", "window_type", "window_number",
    "start_sample", "end_sample_exclusive",
    "mean", "variance", "skewness", "kurtosis",
]


def csv_needs_header(path, fields):
    if not path.exists() or path.stat().st_size == 0:
        return True
    with path.open(newline="", encoding="utf-8") as file:
        if next(csv.reader(file), None) != fields:
            raise ValueError(f"Unexpected columns in {path}. Use a fresh --output folder.")
    return False


def find_burst_segments(signal, threshold=0.2, block_size=1000, segment_length=5000):
    usable = (signal.size // block_size) * block_size
    blocks = signal[:usable].reshape(-1, block_size)
    block_power = np.mean(np.abs(blocks)**2, axis=1)
    active = block_power > threshold
    rising_edges = np.flatnonzero((~active[:-1]) & active[1:]) + 1

    segments = []
    last_end = 0
    for block_index in rising_edges:
        # Skip the first active block, which may include quiet samples.
        start = (block_index + 1) * block_size
        end = start + segment_length
        if end > usable or start < last_end:
            continue
        first_block = start // block_size
        last_block = (end - 1) // block_size
        if not np.all(active[first_block:last_block + 1]):
            continue

        segments.append((start, signal[start:end]))
        last_end = end

    return segments


def extract_features(segment):
    from scipy.stats import kurtosis, skew

    magnitude = np.abs(segment)
    return {
        "mean": float(np.mean(magnitude)),
        "variance": float(np.var(magnitude)),
        "skewness": float(skew(magnitude)),
        "kurtosis": float(kurtosis(magnitude)),
    }


def save_capture_features(path, capture_id, device_id, windows, window_type):
    if not windows:
        return 0
    write_header = csv_needs_header(path, FEATURE_FIELDS)

    with path.open("a", newline="", encoding="utf-8") as file:
        feature_writer = csv.DictWriter(file, fieldnames=FEATURE_FIELDS)
        if write_header:
            feature_writer.writeheader()
        for number, (start, segment) in enumerate(windows, start=1):
            feature_writer.writerow({
                "capture_id": capture_id,
                "device_id": device_id,
                "window_type": window_type,
                "window_number": number,
                "start_sample": start,
                "end_sample_exclusive": start + segment.size,
                **extract_features(segment),
            })
    return len(windows)


def parse_args():
    parser = argparse.ArgumentParser(description="Capture or import I/Q recordings")
    parser.add_argument("--mode", choices=("simulation", "pluto", "dataset"), default="simulation")
    parser.add_argument("--output", default="rf_dataset")
    parser.add_argument("--count", type=int, default=5)
    parser.add_argument("--channel", type=int, default=11)
    parser.add_argument("--sample-rate", type=int, default=4_000_000)
    parser.add_argument("--samples", type=int, default=262_144)
    parser.add_argument("--gain", type=float, default=30.0)
    parser.add_argument("--device-id", default="unverified")
    parser.add_argument("--dataset")
    parser.add_argument("--extract-features", action="store_true")
    parser.add_argument("--burst-threshold", type=float, default=0.2)
    return parser.parse_args()


def extract_samples_from_dataset(dataset_path):
    # Load only trusted pickle files.
    with dataset_path.open("rb") as file:
        data = pickle.load(file)
    main_signal = np.asarray(data["data"][0][0][0][0])
    i = main_signal[:, :, 0]
    q = main_signal[:, :, 1]
    return (i + 1j * q).astype(np.complex64)


def main():
    args = parse_args()
    if not 11 <= args.channel <= 26:
        raise ValueError("IEEE 802.15.4 2.4 GHz channel must be 11–26")
    if args.count < 1 or args.samples < 1 or args.sample_rate < 1:
        raise ValueError("Count, samples, and sample rate must be positive")

    frequency = 2_405_000_000 + (args.channel - 11) * 5_000_000
    output = Path(args.output)
    recordings = output / "recordings"
    metadata = output / "captures.csv"
    features_path = output / "burst_features.csv"
    write_header = csv_needs_header(metadata, FIELDS)
    run_features = args.extract_features and args.mode != "simulation"
    if run_features:
        csv_needs_header(features_path, FEATURE_FIELDS)

    dataset_samples = None
    whole_recording = False
    if args.mode == "dataset":
        if not args.dataset:
            raise ValueError("Dataset path is required when using dataset mode")
        dataset_path = Path(args.dataset)
        if dataset_path.suffix.lower() == ".bin":
            # INRIA binary files contain complex64 I/Q samples.
            if dataset_path.stat().st_size % np.dtype(np.complex64).itemsize:
                raise ValueError(f"Incomplete complex64 sample in {dataset_path}")
            signal = np.fromfile(dataset_path, dtype=np.complex64)
            if signal.size == 0:
                raise ValueError(f"No I/Q samples in {dataset_path}")
            dataset_samples = [signal]
        else:
            dataset_samples = extract_samples_from_dataset(dataset_path)
            whole_recording = True
        if args.count > len(dataset_samples):
            raise ValueError(
                f"Requested {args.count} recordings, but only "
                f"{len(dataset_samples)} are available"
            )

    sdr = None
    if args.mode == "pluto":
        import adi

        sdr = adi.Pluto()
        sdr.sample_rate = args.sample_rate
        sdr.rx_lo = frequency
        sdr.rx_rf_bandwidth = min(args.sample_rate, 4_000_000)
        sdr.gain_control_mode_chan0 = "manual"
        sdr.rx_hardwaregain_chan0 = args.gain
        sdr.rx_buffer_size = args.samples

    recordings.mkdir(parents=True, exist_ok=True)
    with metadata.open("a", newline="", encoding="utf-8") as file:
        capture_writer = csv.DictWriter(file, fieldnames=FIELDS)
        if write_header:
            capture_writer.writeheader()

        for index in range(args.count):
            timestamp = datetime.now(timezone.utc)
            capture_id = timestamp.strftime("%Y%m%dT%H%M%S%fZ") + f"_{index:04d}"

            if args.mode == "dataset":
                samples = dataset_samples[index]
            elif args.mode == "simulation":
                rng = np.random.default_rng(index)
                samples = (
                    rng.standard_normal(args.samples)
                    + 1j * rng.standard_normal(args.samples)
                ).astype(np.complex64)
            else:
                samples = np.asarray(sdr.rx(), dtype=np.complex64).reshape(-1)

            filename = f"{capture_id}.npy"
            np.save(recordings / filename, samples)
            capture_writer.writerow({
                "capture_id": capture_id,
                "time_utc": timestamp.isoformat(),
                "device_id": args.device_id,
                "label_status": "unverified",
                "channel": "" if args.mode == "dataset" else args.channel,
                "channel_frequency_hz": "" if args.mode == "dataset" else frequency,
                "sample_rate_hz": "" if args.mode == "dataset" else args.sample_rate,
                "gain_db": args.gain if args.mode == "pluto" else "",
                "sample_count": samples.size,
                "iq_file": f"recordings/{filename}",
                "start_trame": "",
                "End_trame": "",
            })
            file.flush()
            print(f"Saved {filename}: {samples.size} complex samples")

            if run_features:
                if whole_recording:
                    windows = [(0, samples)]
                    window_type = "whole_recording"
                else:
                    windows = find_burst_segments(samples, threshold=args.burst_threshold)
                    window_type = "burst"

                count = save_capture_features(
                    features_path, capture_id, args.device_id, windows, window_type
                )
                print(f"Extracted {count} feature windows from {filename}")


if __name__ == "__main__":
    main()
