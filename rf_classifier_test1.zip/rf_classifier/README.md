# RF Classifier

This TRU capstone project explores whether recorded ZigBee radio signals can help verify a device's identity. Given a packet and a claimed device ID, the verifier compares measurements from the packet with a profile of that device. Mahalanobis distance accepts close matches, rejects clear mismatches, and sends borderline cases to a calibrated support vector machine (SVM) for a decision.

The project uses recorded in-phase and quadrature (I/Q) samples from a ZigBee benchmark. It compares features based on I/Q statistics and phase with features from the preamble, the repeated pattern at the start of a packet. The benchmark runs offline. [ZigBee RF fingerprinting dataset study](https://doi.org/10.1109/JIOT.2023.3281644)

## Start live pair verification

Open PowerShell in the extracted `rf_classifier` folder. Install the Python packages and point the server at your recording folders.

```powershell
py -m pip install numpy pandas scipy scikit-learn h5py
py .\serve_dashboard.py --data-dir "$HOME\Downloads\ZigBee_RFF"
```

Use the address printed by the command, normally `http://127.0.0.1:8000/`. Leave PowerShell open while using the dashboard. Press **Ctrl+C** there to stop it. The server listens on this computer only and loads your recorded MATLAB files.

1. Select two different devices in **Recording A** and **Recording B**. **Live verification** fits a model for those IDs and updates automatically. The first run reads the raw recordings. Later choices reuse the extracted features during the session.
2. **Recording B** sets the evaluation condition. The selected devices both need a recording in that condition. Keep the default **Train SVM on Recording B’s condition** to use early target packets. Select **Recording A’s condition** to test transfer between conditions.
3. In **Configuration**, choose the condition-specific candidate or a baseline. The original and ×1.5 rejection-cutoff options let you compare how much reaches the SVM while keeping the candidate's features and starting sample.
4. Read the pair totals and the Mahalanobis and SVM acceptance counts for each device. Either selected device, including a reserved ID you select, is enrolled for this pair. Other available reserved devices provide the unseen test packets. The metrics use later usable frames. Shorter recordings, such as LOS, can use fewer than 100 profile frames.

**I/Q features** shows variance, skewness, and excess kurtosis for I and Q separately. The values update as you select a device, condition, or frame. They use the same 512-sample window as the I/Q baseline (offsets 170–681), after removing DC offset and normalizing RMS. The plots show the recorded samples.

### Show live Arduino sensor readings

Upload a sketch to the Arduino MKR WiFi 1010 (on the MKR IoT Carrier) that prints one JSON line per reading at 115200 baud, such as `{"temperatureC":23.91,"humidityPct":36.58,"pressureKpa":101.25}`. Close the Arduino IDE Serial Monitor, install `pyserial`, then add `--serial auto` (or the port, such as `/dev/cu.usbmodem113201` or `COM3`):

```powershell
py -m pip install pyserial
py .\serve_dashboard.py --data-dir "$HOME\Downloads\ZigBee_RFF" --serial auto
```

The **Live sensors** section shows the latest temperature, humidity and pressure with the last 10 minutes charted. Every reading is also appended to `sensor_log.csv` beside the server script (change it with `--sensor-log`). If the board is unplugged, the dashboard says so and resumes when it is plugged back in. `arduino_bridge.py` reads the port; `dashboard/environment.js` draws the panel.

### Stream a live-style radio feed

With no SDR attached, add `--radio-replay` to play recorded packets back one at a time, every 0.6–1.6 s from a random transmitter, as a receiver would hear them. Pick the starting condition with `--radio-replay Outdoor_NLOS` (default `Indoor_NLOS`) or switch it from the **Live radio feed** section.

```powershell
py .\serve_dashboard.py --data-dir "$HOME\Downloads\ZigBee_RFF" --serial auto --radio-replay
```

Each packet shows its waveform, power, signal quality and carrier frequency offset, plus the Arduino's temperature, humidity and pressure when it arrived. The panel always names the recording and frame each packet came from, since these are replayed recordings, not over-the-air captures. `radio_feed.py` runs the replay; `dashboard/radio.js` draws the panel.

### Compare Tier 2 SVMs

Use **Tier 2 SVM → Genuine vs non-genuine claim** to test a binary SVM for each enrolled ID. It learns from genuine packets for that ID and nonmatching packets from other development devices. Separate early validation packets set the minimum score needed for acceptance. Available extra development devices are split between training and validation. Reserved devices are kept for testing unless selected as enrolled for this pair.

The **Device classifier** option picks an enrolled ID. The **claim verifier** judges each routed claim independently and can decline both claims for one packet. Switch between the two with the same pair, recordings, and configuration to compare them. A fixed cutoff configuration keeps the Mahalanobis review band the same between models. The adaptive option tunes the band separately using each SVM's validation decisions.

### Review hard rejections

The pair table shows how many genuine packets Mahalanobis rejected outright. Under **Audit Tier 1 rejections**, the dashboard reports how many genuine rejects the SVM would recover and how many additional wrong-ID or unseen packets it would accept. The audit is a counterfactual scored on the same test packets.

Choose **Tune each device’s rejection cutoff** to try a validation-based review band. The verifier starts with the unscaled upper cutoff and tests ×1.25, ×1.5, and ×2 separately for each selected device. It widens a device’s cutoff when that recovers more genuine claims and adds zero wrong-ID accepts on the separate validation frames. The seven reserved devices, apart from any selected as enrolled, are evaluated on the held-out test portion. Short recordings may lack a separate cutoff-tuning block and use the original cutoffs.

The candidate uses sample 170, preamble + I/Q statistics and a ×1.5 upper rejection cutoff for Indoor NLOS. Outdoor NLOS uses sample 320, preamble features and the original cutoff. LOS uses the shared preamble setup at sample 170. The **Why the indoor and outdoor candidates differ** table shows the fixed observations that motivated these settings. Those observations used nine enrolled devices per split. Live pair runs enroll two.

To regenerate the fixed NLOS findings table from the same recording protocol, run:

```powershell
py .\evaluate_nlos_candidates.py --data-dir "$HOME\Downloads\ZigBee_RFF"
```

The server discovers the LOS and NLOS folders present in your dataset. To load a saved LOS/NLOS comparison into **Saved verification benchmarks**, put `los_nlos_comparison.csv` beside the server script or pass its path with `--comparison`. Live comparisons work without that CSV.

## Open the bundled snapshot

Extract the ZIP and open `dashboard/index.html` in a browser. In PowerShell, from the extracted `rf_classifier` folder:

```powershell
Start-Process .\dashboard\index.html
```

This file-based view includes the saved benchmarks and packet replay. Use the server to fit new pairs. The included data covers 19 devices and 38 recordings across Indoor NLOS and Outdoor NLOS. NLOS means non-line-of-sight. You can explore the included data without installing Python or downloading the original recordings.

| Section | How to use it |
| --- | --- |
| **Signals** | Choose two recordings and preview frames, then switch between I/Q traces, magnitude, and constellation plots. Each preview shows the first 768 samples. |
| **Verification** | Choose a feature set and evaluation protocol to see the saved results. The panel shows which recordings were used for training, profiling, and testing. Select **All 12 enrolled devices** for results across the full enrolled group. Where a dedicated experiment exists for the selected pair, the panel can show that pair's results. |
| **Packet simulation** | Choose an unenrolled sender, a claimed device ID, and a recorded frame, then select **Send packet**. The panel shows the Mahalanobis decision, the SVM decision when applicable, and the final verdict. This is an offline replay of saved decisions. |
| **Recordings** | Browse or filter the available recordings and select a file for either comparison slot. |

Changing a preview frame changes the signal plot. To switch experiments, use the **Evaluation** menu in the section you are viewing.

## Set up the dataset

Run the remaining commands in PowerShell from the `rf_classifier` folder that contains this README. Install the Python dependencies:

```powershell
py -m pip install numpy pandas scipy scikit-learn h5py
```

Place the original MATLAB recordings in a `dataset` folder. Keep the recording filenames as supplied. The NLOS experiments use the two NLOS folders. The four-condition comparison also uses the two LOS folders, where LOS means line of sight.

```text
rf_classifier/
├── dataset/
│   ├── Indoor_NLOS/
│   ├── Outdoor_NLOS/
│   ├── Indoor_LOS/
│   └── Outdoor_LOS/
└── dashboard/
```

Each condition folder should contain `No_<device>_F5_1.mat` for devices **1, 2, and 10 through 26** when running the full benchmark. For example, device 10's file is `No_10_F5_1.mat` in each folder. The ZIP includes dashboard snapshots and benchmark results. You supply the original `.mat` recordings to rerun the experiments. For commands with `--data-dir`, you can point to a different dataset location by passing its path in quotes.

## Run the main experiments

**Reproduce the NLOS benchmark.** This writes counts and rates for genuine claims, incorrect claims, unseen devices, and SVM routing. The optional `--pairs` flag also evaluates all 66 pairs of enrolled devices for the supported protocols. The ZIP includes a copy of this CSV for the dashboard.

```powershell
py .\evaluate_preamble_gatekeeper.py --data-dir .\dataset --pairs --output .\gatekeeper_results.csv
```

**Compare LOS and NLOS and load both into the dashboard.** With all four condition folders in place, run these commands in order. The first writes the comparison CSV. The second uses it and the existing `gatekeeper_results.csv` to build the signal previews and verification tables. The third exports packet replay decisions for both outdoor conditions.

```powershell
py .\compare_los_nlos.py --data-dir .\dataset --output .\los_nlos_comparison.csv
py .\build_dashboard_data.py --data-dir .\dataset --comparison .\los_nlos_comparison.csv
py .\export_packet_simulation.py --data-dir .\dataset
Start-Process .\dashboard\index.html
```

The dashboard should show **4 conditions and 76 recordings**. In **Verification**, select a LOS or NLOS evaluation to see the side-by-side results. In **Packet simulation**, select an Outdoor LOS or Outdoor NLOS evaluation. To refresh the NLOS signal previews and verification tables with only the two NLOS folders, run `build_dashboard_data.py` with `--data-dir .\dataset` and omit `--comparison`.

In the LOS/NLOS comparison, the SVM trains on indoor recordings in both modes. The indoor-only mode also builds profiles and calibrates indoors. The outdoor-calibrated mode uses the first 69 usable frames from each enrolled outdoor device to build profiles, calibrate SVM scores, and set thresholds. Both modes test on the same later outdoor frames, starting at the 70th usable frame. Devices 20–26 are held out as unseen senders throughout fitting and calibration. A frame from one of these devices counts as falsely accepted if any enrolled ID is accepted for it. Outdoor calibration and testing use different frames from the same outdoor recordings.

## File guide

| File | What it does |
| --- | --- |
| `serve_dashboard.py` | Starts the local dashboard and serves live previews and pair evaluation results. |
| `live_pair_evaluation.py` | Loads frames for the chosen devices and fits and scores a new pair verifier using held-out packets. |
| `dashboard/live-pair.js` | Requests fresh results when the device pair or evaluation settings change. |
| `evaluate_nlos_candidates.py` | Recalculates the four-split NLOS experiments used to describe the indoor and outdoor candidates. |
| `dashboard/nlos-findings.js` | Contains the saved candidate results shown alongside the live pair evaluation. |
| `signal_features.py` | Reads MATLAB I/Q recordings and their frame boundaries. It normalizes samples and extracts I/Q statistics, phase, and repeated-preamble features. The evaluators import it. |
| `evaluate_preamble_gatekeeper.py` | Runs the two-stage verifier using normalized I/Q plus phase or repeated-preamble features. Evaluates several indoor and outdoor training, calibration, and test combinations. |
| `compare_los_nlos.py` | Runs matching indoor-to-outdoor experiments for LOS and NLOS. Prints rates and percentage-point differences and writes `los_nlos_comparison.csv`. |
| `gatekeeper_results.csv` | Stores NLOS benchmark counts, totals, and percentages for the full cohort, individual devices, and supported pair experiments. |
| `build_dashboard_data.py` | Reads the recordings and result CSVs and writes the signal previews, recording list, and verification tables to `dashboard/dashboard-data.js`. |
| `export_packet_simulation.py` | Evaluates held-out packets against enrolled IDs and writes the per-packet decisions and distances to `dashboard/packet-data.js`. |
| `dashboard/index.html` | Opens the dashboard in a browser. |
| `dashboard/dashboard.css` | Styles the dashboard. |
| `dashboard/dashboard.js` | Handles recording selection, signal plots, verification tables, and recording filters. |
| `dashboard/dashboard-data.js` | Contains the signal previews, recording metadata, and benchmark results loaded by the dashboard. |
| `dashboard/packet-replay.js` | Handles the packet replay controls and displays each verifier decision and the aggregate counts. |
| `dashboard/packet-data.js` | Contains the saved packet decisions used by the replay controls. |

## Run the baseline and feature experiments

These scripts investigate what happens when the features, calibration, or frame alignment change. Run them from the project root with the original NLOS recordings under `dataset`.

| File | What it does |
| --- | --- |
| `evaluate_rf_classifier.py` | Compares I/Q statistics, phase, and their combination in an SVM evaluation. Add `--mahalanobis` to include its Mahalanobis and SVM verification test. |
| `test_strict_gatekeeper.py` | Compares a calibrated SVM baseline with a fast-pass experiment where claims that miss the Mahalanobis acceptance cutoff are routed to the SVM. Includes a test on separate indoor recordings. |
| `compare.py` | Compares phase, magnitude, autocorrelation, and spectral features. It produces a feature cache used by other experiments. |
| `preamble.py` | Compares features extracted from repeated waveform blocks near the start of a packet. Run it after `compare.py`. |
| `test_raw_normalization.py` | Compares raw I/Q, power normalization, offset removal, and phase-drift correction. It saves a cache for the evaluation protocol test. |
| `test_known_preamble.py` | Uses a matched filter to look for the IEEE 802.15.4 preamble and start-of-frame delimiter. It compares fixed and detected feature windows and saves the detection results. |
| `test_nominal_preamble_offset.py` | Tests a feature window near the detected preamble start and uses the fixed offset when detection confidence is low. Run it after `test_known_preamble.py`. |
| `test_evaluation_protocol.py` | Tests time-ordered splits, cross-condition transfer, different sizes of calibration sets, and unseen devices. It uses the feature caches from `compare.py` and `test_raw_normalization.py`. |

```powershell
py .\evaluate_rf_classifier.py --data-dir .\dataset --features compare --mahalanobis
py .\test_strict_gatekeeper.py --data-dir .\dataset
py .\compare.py
py .\preamble.py
py .\test_raw_normalization.py
py .\test_known_preamble.py
py .\test_nominal_preamble_offset.py
py .\test_evaluation_protocol.py
```

To run the main evaluator or strict gatekeeper on a smaller subset, add `--devices 17 22` and provide the recordings for those IDs in both NLOS folders. The main evaluator also accepts compatible `*_phase512_features.csv` files from a single directory with `--format csv --features phase`. The exploratory scripts reuse generated files in `rf_scratch/`. If you switch datasets, move that cache directory aside before running them again.

The preamble timing experiments use the IEEE 802.15.4 synchronization pattern and a 10 MS/s sampling assumption. [IEEE 802.15.4-2003 standard](https://labs.ece.uw.edu/funlab/802_15/802.15.4-std.pdf) · [Sampling-rate reference](https://ietresearch.onlinelibrary.wiley.com/doi/full/10.1049/ell2.13032)

## Capture and early classifier scripts

| File | What it does and how to run it |
| --- | --- |
| `legacy/data_collection_script.py` | Generates simulated I/Q samples, imports supported recordings, or captures raw I/Q using an ADALM-Pluto SDR. Writes `.npy` recordings and capture metadata. Run `py .\legacy\data_collection_script.py --help` for the input and hardware options. Pluto mode requires the SDR and the `adi` Python module. Raw captures need packet synchronization and labeled sessions before they can feed the benchmark evaluator. |
| `legacy/train_svm.py` | Runs the two-device SVM for devices 10 and 11 and reports accuracy and recall. Put the four `Indoor_NLOS_No_<device>_F5_1_iq_features.csv` and `Outdoor_NLOS_No_<device>_F5_1_iq_features.csv` files in your working directory, then run `py .\legacy\train_svm.py` from the project root. |

To try the capture script without hardware, generate one synthetic recording:

```powershell
py .\legacy\data_collection_script.py --mode simulation --count 1 --output .\rf_dataset
```
