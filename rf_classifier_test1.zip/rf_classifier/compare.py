from pathlib import Path

import numpy as np
from sklearn.metrics import confusion_matrix
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

from evaluate_rf_classifier import read_mat

DEVICES = [1, 2, *range(10, 27)]
DEVELOPMENT = [1, 2, *range(10, 20)]
RESERVED = list(range(20, 27))


def recording_path(condition, device):
    folder = 'Indoor_NLOS' if condition == 'in' else 'Outdoor_NLOS'
    return Path('dataset') / folder / f'No_{device}_F5_1.mat'


def load_frames(path):
    samples, indices = read_mat(path)
    indices = indices.astype(int)
    starts, ends = indices.T
    assert len(starts) > 0 and starts.min() >= 1 and ends.max() <= len(samples)
    assert np.all(ends - starts >= 8383)
    frames = samples[(starts-1)[:,None] + np.arange(8384)]
    assert np.isfinite(frames).all() and np.iscomplexobj(frames)
    return frames


def phase_features(z):
    a, b = z[:, :-1], z[:, 1:]
    ok = (a != 0) & (b != 0)
    d = np.angle(b * a.conj())
    return np.column_stack([(np.sin(d)*ok).sum(1)/ok.sum(1), (np.cos(d)*ok).sum(1)/ok.sum(1)])


def magnitude_features(z):
    amp = abs(z)
    rms = np.sqrt(np.mean(amp**2, axis=1, keepdims=True))
    norm = amp / np.maximum(rms, 1e-12)
    quantiles = np.quantile(norm, [.1,.25,.5,.75,.9,.99], axis=1).T
    moments = np.column_stack([np.mean(norm**k,axis=1) for k in [1,3,4,6]])
    return np.column_stack([quantiles, moments])


def acf_features(z, amplitude=False):
    if amplitude:
        z = abs(z)
        z = z-z.mean(1,keepdims=True)
    lag_values = [1,2,3,4,5,6,8,10,12,16,20,24,32,40,48,64,80,96,128,160,192,256,320,384,512,640]
    out = []
    for lag in lag_values:
        a,b = z[:,:-lag],z[:,lag:]
        scale=np.sqrt(np.sum(abs(a)**2,axis=1)*np.sum(abs(b)**2,axis=1))
        out.append(abs(np.sum(b*a.conj(),axis=1))/np.maximum(scale,1e-12))
    return np.column_stack(out)


def spec_features(z, centered):
    z = z[:, :8192].reshape(len(z), 8, 1024)
    psd = np.mean(abs(np.fft.fftshift(np.fft.fft(z*np.hanning(1024),axis=-1),axes=-1))**2,axis=1)
    psd /= psd.sum(1,keepdims=True)
    if centered:
        n=psd.shape[1]
        center=np.angle(psd @ np.exp(2j*np.pi*np.arange(n)/n))*n/(2*np.pi)
        indices=(np.arange(n)[None,:]+np.rint(center).astype(int)[:,None]-n//2)%n
        psd=np.take_along_axis(psd,indices,axis=1)
    return np.log10(psd.reshape(len(z),32,32).sum(2)+1e-12)


def extract(z):
    steady=z[:,170:]
    steady_power=np.mean(abs(steady)**2,axis=1)
    envelope=np.column_stack([
        np.log10(np.mean(abs(z[:, start:stop])**2,axis=1)/steady_power+1e-12)
        for start,stop in zip(range(0,320,20),range(20,340,20))
    ])
    return {
        'phase512':phase_features(z[:,170:682]),
        'long_phase':phase_features(steady),
        'amplitude_shape':magnitude_features(steady),
        'onset_envelope':envelope,
        'absolute_power':np.log10(steady_power)[:,None],
        'complex_acf':acf_features(steady),
        'amplitude_acf':acf_features(steady,amplitude=True),
        'spectrum':spec_features(steady,False),
        'centered_spectrum':spec_features(steady,True),
    }


def run_eval(data, ids, groups, reverse=False):
    source,target=('out','in') if reverse else ('in','out')
    def pack(condition):
        return np.concatenate([np.column_stack([data[condition,n][group] for group in groups]) for n in ids])
    X_train,X_test=pack(source),pack(target)
    y_train=np.repeat(ids,[len(data[source,n][groups[0]]) for n in ids])
    y_test=np.repeat(ids,[len(data[target,n][groups[0]]) for n in ids])
    model=make_pipeline(StandardScaler(), SVC(C=1, gamma='scale'))
    model.fit(X_train,y_train)
    prediction=model.predict(X_test)
    return confusion_matrix(y_test,prediction,labels=ids)


def main():
    cached=Path('rf_scratch/features.npz')
    cached.parent.mkdir(exist_ok=True)
    if not cached.exists():
        flat={}
        for device in DEVICES:
            for condition in ('in','out'):
                individual=Path(f'rf_scratch/{condition}_{device}.npz')
                if not individual.exists():
                    z=load_frames(recording_path(condition, device))
                    np.savez_compressed(individual,**extract(z))
                with np.load(individual) as saved:
                    extracted={name:saved[name] for name in saved.files}
                for key,value in extracted.items():
                    assert np.isfinite(value).all()
                    flat[f'{condition}_{device}_{key}']=value
            print('Extracted', device, flush=True)
        np.savez_compressed(cached,**flat)
    data={}
    with np.load(cached) as saved:
        for k in saved.files:
            condition,device,name=k.split('_',2)
            data.setdefault((condition,int(device)),{})[name]=saved[k]
    groups={name:[name] for name in data['in',1]}
    groups.update({
        'amplitude': ['amplitude_shape','onset_envelope','amplitude_acf'],
        'normalized': ['amplitude_shape','complex_acf','amplitude_acf','centered_spectrum'],
        'normalized+onset': ['amplitude_shape','complex_acf','amplitude_acf','centered_spectrum','onset_envelope'],
        'frequency+onset': ['centered_spectrum','onset_envelope'],
    })
    for label,g in groups.items():
        matrix=run_eval(data,DEVELOPMENT,g)
        print('DEV', label, np.trace(matrix), matrix.sum(), np.round(matrix.diagonal()/231,3))
    # Pick on development devices only.
    selected=max(groups,key=lambda name:np.trace(run_eval(data,DEVELOPMENT,groups[name])))
    for ids,name in [(RESERVED,'RESERVED'),(DEVICES,'ALL')]:
        for label in dict.fromkeys(['phase512', selected]):
            matrix=run_eval(data,ids,groups[label])
            print(name,label,np.trace(matrix),matrix.sum(),np.round(matrix.diagonal()/231,3))
            print(matrix)
    print('SELECTED',selected)

if __name__=='__main__':
    main()
