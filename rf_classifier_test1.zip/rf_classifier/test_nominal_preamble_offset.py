"""Compare preamble alignment at a location close to the original feature window."""
import numpy as np
import test_known_preamble as p

# The nominal preamble start was about 133-134. Offset 37 keeps the
# reference-window region comparable to the original absolute offset 170.
RELATIVE_OFFSET = 37
with np.load("rf_scratch/known_preamble_features.npz") as data:
    normalized = {}
    for n in p.DEVICES:
        for cond in ("in", "out"):
            diag = data[f"{cond}_{n}_diag"]
            trusted = diag[:, 3].astype(bool)
            raw = p.load_frames(p.recording_path(cond, n))
            start = np.where(trusted, diag[:, 0] + RELATIVE_OFFSET, 170).astype(int)
            low = start < 0
            start[low] = 170
            window = raw[np.arange(len(raw))[:,None], start[:,None] + np.arange(512)]
            normalized[cond,n] = p.features(p.normalization(window))
        print("Checked nominal offset for", n, flush=True)
    for method in ("fixed_norm", "fallback_norm", "matched_nominal_norm"):
        indoor = [normalized["in",n] if method=="matched_nominal_norm" else data[f"in_{n}_{method}"] for n in p.DEVICES]
        outdoor = [normalized["out",n] if method=="matched_nominal_norm" else data[f"out_{n}_{method}"] for n in p.DEVICES]
        x,y = p.e.stack_by_device(indoor,p.DEVICES)
        xc,yc = p.e.stack_by_device([a[:69] for a in outdoor],p.DEVICES)
        xt,yt = p.e.stack_by_device([a[69:] for a in outdoor],p.DEVICES)
        model = p.e.make_pipeline(p.e.StandardScaler(),p.e.SVC(decision_function_shape="ovo")).fit(x,y)
        cal = p.e.make_pipeline(p.e.StandardScaler(),p.e.LogisticRegression(C=1,max_iter=2000))
        cal.fit(model.decision_function(xc),yc)
        print(method, "zero/cal", f"{model.score(xt,yt):.4%}",
              f"{cal.score(model.decision_function(xt),yt):.4%}", flush=True)
