"""Evaluate I/Q statistics and phase features with indoor and outdoor recordings.

For MATLAB input, DATA_DIR contains the Indoor_NLOS and Outdoor_NLOS folders.
For CSV input, DATA_DIR contains the existing scenario-prefixed phase512 CSVs.
Raw MATLAB input supports statistics, phase, and their combination.
"""

import argparse
from itertools import combinations
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.io import loadmat
from scipy.spatial.distance import cdist
from sklearn.covariance import LedoitWolf
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

INDOOR = "Indoor_NLOS"
OUTDOOR = "Outdoor_NLOS"
PHASE_COLUMNS = ["phase_sin", "phase_cos"]
STAT_COLUMNS = [
    f"{component}_{statistic}"
    for component in ("i", "q")
    for statistic in ("variance", "skewness", "excess_kurtosis")
]
FEATURE_SETS = {
    "stats": STAT_COLUMNS,
    "phase": PHASE_COLUMNS,
    "combined": STAT_COLUMNS + PHASE_COLUMNS,
}
DEFAULT_DEVICES = [1, 2, *range(10, 27)]


def read_mat(path):
    try:
        data = loadmat(path, variable_names=["all_data_segement", "data_index"])
        return data["all_data_segement"].ravel(), data["data_index"]
    except NotImplementedError:
        # MATLAB 7.3 stores complex arrays as HDF5 records with real/imag fields.
        try:
            import h5py
        except ImportError as error:
            raise ValueError(
                f"{path.name} uses MATLAB 7.3. Install h5py to read it."
            ) from error
        with h5py.File(path, "r") as data:
            samples = np.asarray(data["all_data_segement"]).ravel()
            indices = np.asarray(data["data_index"]).T
        if samples.dtype.names == ("real", "imag"):
            samples = samples["real"] + 1j * samples["imag"]
        return samples, indices


def calculate_iq_moments(windows):
    """Return population variance, skewness and excess kurtosis for I and Q."""
    columns = []
    for component in (windows.real, windows.imag):
        centered = component - component.mean(axis=1, keepdims=True)
        variance = np.mean(centered**2, axis=1)
        with np.errstate(divide="ignore", invalid="ignore"):
            standardized = centered / np.sqrt(variance)[:, None]
        columns.extend([
            variance,
            np.mean(standardized**3, axis=1),
            np.mean(standardized**4, axis=1) - 3,
        ])
    return np.column_stack(columns)


def extract_mat_features(path, columns):
    samples, indices = read_mat(path)
    if not np.iscomplexobj(samples):
        raise ValueError(f"{path} must contain complex I/Q samples.")
    if indices.ndim != 2 or indices.shape[1] != 2 or not len(indices):
        raise ValueError(f"{path} must contain a nonempty N-by-2 data_index.")
    if not np.isfinite(indices).all() or np.any(indices != np.floor(indices)):
        raise ValueError(f"{path} contains invalid frame indices.")

    starts, ends = indices.astype(np.int64).T
    if np.any(starts < 1) or np.any(ends < starts) or np.any(ends > len(samples)):
        raise ValueError(f"{path} contains frame indices outside the recording.")

    # MATLAB starts at 1. Python offsets 170 through 681 give 512 samples.
    complete = ends - starts + 1 >= 682
    windows = samples[(starts[complete] - 1)[:, None] + np.arange(170, 682)]
    windows = windows[np.isfinite(windows).all(axis=1)]
    features = pd.DataFrame(index=np.arange(len(windows)))
    if "i_variance" in columns:
        features[STAT_COLUMNS] = calculate_iq_moments(windows)
    if "phase_sin" in columns:
        earlier, later = windows[:, :-1], windows[:, 1:]
        valid = (earlier != 0) & (later != 0)
        phase_change = np.angle(later * earlier.conj())
        counts = valid.sum(axis=1)
        with np.errstate(divide="ignore", invalid="ignore"):
            features["phase_sin"] = (np.sin(phase_change) * valid).sum(axis=1) / counts
            features["phase_cos"] = (np.cos(phase_change) * valid).sum(axis=1) / counts
    features = features[columns]
    features = features.loc[np.isfinite(features.to_numpy()).all(axis=1)]
    skipped = len(indices) - len(features)
    if skipped:
        print(f"{path.name}: skipped {skipped} unusable frames")
    return features


def load_features(root, input_format, scenario, device, columns):
    stem = f"No_{device}_F5_1"
    if input_format == "mat":
        path = root / scenario / f"{stem}.mat"
        features = extract_mat_features(path, columns)
    else:
        path = root / f"{scenario}_{stem}_phase512_features.csv"
        frame = pd.read_csv(path)
        if not frame["scenario"].eq(scenario).all():
            raise ValueError(f"{path} contains a different recording condition.")
        if not frame["source_file"].eq(f"{stem}.mat").all():
            raise ValueError(f"{path} contains a different source recording.")
        frame["frame"] = pd.to_numeric(frame["frame"])
        if not np.isfinite(frame["frame"]).all() or frame["frame"].duplicated().any():
            raise ValueError(f"{path} contains missing or duplicate frame numbers.")
        features = frame.sort_values("frame")[columns].astype(float)

    if features.empty or not np.isfinite(features.to_numpy()).all():
        raise ValueError(f"{path} has no usable data or non-finite features.")
    return features


def stack_by_device(recordings, devices):
    labels = np.repeat(devices, [len(recording) for recording in recordings])
    return np.concatenate(recordings), labels


def choose_cutoff(lower, higher):
    """Fit a cutoff on labeled calibration scores for one device pair."""
    values = np.unique(np.concatenate([lower, higher]))
    midpoints = (values[:-1] + values[1:]) / 2
    cutoffs = np.r_[0.0, np.nextafter(values[0], -np.inf), midpoints, values[-1]]
    balanced = (lower[:, None] <= cutoffs).mean(axis=0)
    balanced += (higher[:, None] > cutoffs).mean(axis=0)
    best = np.flatnonzero(np.isclose(balanced, balanced.max(), rtol=0, atol=1e-12))
    return cutoffs[best[np.argmin(np.abs(cutoffs[best]))]]


def predict_with_pairwise_cutoffs(devices, scores_cal, labels_cal, scores_test):
    # Binary SVC scores point toward the higher device ID. Multiclass
    # one-vs-one scores use the opposite sign, so standardize the convention.
    if len(devices) == 2:
        cutoff = choose_cutoff(
            scores_cal[labels_cal == devices[0], 0],
            scores_cal[labels_cal == devices[1], 0],
        )
        print(f"Calibrated binary cutoff: {cutoff:.6f}")
        return np.where(scores_test[:, 0] > cutoff, devices[1], devices[0])

    votes = np.zeros((len(scores_test), len(devices)), dtype=int)
    for column, (low, high) in enumerate(combinations(range(len(devices)), 2)):
        cutoff = choose_cutoff(
            -scores_cal[labels_cal == devices[low], column],
            -scores_cal[labels_cal == devices[high], column],
        )
        score = -scores_test[:, column]
        # Preserve the default multiclass vote when its zero cutoff is selected.
        high_wins = score >= 0 if cutoff == 0 else score > cutoff
        votes[:, low] += ~high_wins
        votes[:, high] += high_wins

    # np.argmax breaks vote ties in ascending device-ID order.
    return devices[votes.argmax(axis=1)]


def report_verification(label, accepted, genuine, routed):
    genuine_rate = accepted[genuine].mean()
    false_accept_rate = accepted[~genuine].mean()
    genuine_routed = routed[genuine].mean()
    frames_routed = routed.any(axis=1).mean()
    unique_correct = ((accepted.sum(axis=1) == 1) & (accepted & genuine).any(axis=1)).mean()
    print(
        f"{label}: genuine accepted {genuine_rate:.2%}, "
        f"incorrect claims accepted {false_accept_rate:.2%}, "
        f"genuine claims routed {genuine_routed:.2%}, "
        f"frames routed when checking all claims {frames_routed:.2%}, "
        f"unique correct ID {unique_correct:.2%}"
    )


def evaluate_gatekeeper(enrollment, test_x, test_y, devices, predict_tier2, label):
    split_points = [len(frames) * 2 // 3 for frames in enrollment]
    if min(split_points) < 2:
        raise ValueError("Each gatekeeper enrollment needs at least three frames per device.")
    references = [frames[:cut] for frames, cut in zip(enrollment, split_points)]
    scaler = StandardScaler().fit(np.concatenate(references))
    test_scaled = scaler.transform(test_x)
    distances = np.empty((len(test_x), len(devices)))
    low = np.empty(len(devices))
    high = np.empty(len(devices))
    for column, (reference, frames, cut) in enumerate(
        zip(references, enrollment, split_points)
    ):
        profile = LedoitWolf().fit(scaler.transform(reference))
        if not np.any(profile.precision_):
            raise ValueError(f"Device {devices[column]} has no feature variation for its profile.")
        validation = scaler.transform(frames[cut:])
        # LedoitWolf.mahalanobis returns squared Mahalanobis distances.
        validation_distances = profile.mahalanobis(validation)
        low[column], high[column] = np.quantile(validation_distances, [0.90, 0.99])
        distances[:, column] = profile.mahalanobis(test_scaled)

    genuine = test_y[:, None] == devices
    trusted = distances <= low
    borderline = (distances > low) & (distances <= high)
    needs_svm = borderline.any(axis=1)
    accepted = trusted.copy()
    if needs_svm.any():
        prediction = predict_tier2(test_x[needs_svm])
        accepted[needs_svm] |= borderline[needs_svm] & (prediction[:, None] == devices)

    report_verification(label, accepted, genuine, borderline)
    nearest = devices[distances.argmin(axis=1)]
    print(f"  Nearest Mahalanobis profile identification: {(nearest == test_y).mean():.2%}")


def evaluate(indoor, outdoor, devices, gatekeeper=False):
    cuts = [len(frames) * 3 // 10 for frames in outdoor]
    if min(cuts) < 1:
        raise ValueError("Each outdoor recording needs at least four usable frames.")

    train_x, train_y = stack_by_device(indoor, devices)
    outdoor_calibration = [frames[:cut] for frames, cut in zip(outdoor, cuts)]
    cal_x, cal_y = stack_by_device(outdoor_calibration, devices)
    test_x, test_y = stack_by_device(
        [frames[cut:] for frames, cut in zip(outdoor, cuts)], devices
    )
    print(f"Devices: {', '.join(map(str, devices))}")
    print(f"Indoor training frames: {len(train_y)}")
    print(f"Outdoor calibration frames (first 30% per device): {len(cal_y)}")
    print(f"Outdoor test frames (remaining frames): {len(test_y)}")

    svm = make_pipeline(StandardScaler(), SVC(kernel="rbf", C=1, gamma="scale",
                                               decision_function_shape="ovo"))
    svm.fit(train_x, train_y)
    scores_cal = svm.decision_function(cal_x).reshape(len(cal_x), -1)
    scores_test = svm.decision_function(test_x).reshape(len(test_x), -1)

    score_model = make_pipeline(
        StandardScaler(), LogisticRegression(C=1, max_iter=2000)
    ).fit(scores_cal, cal_y)
    # Fit reference centers using the early outdoor data only.
    scale = StandardScaler().fit(cal_x)
    outdoor_scaled = scale.transform(cal_x)
    centers = np.array([
        np.median(outdoor_scaled[cal_y == n], axis=0) for n in devices
    ])
    nearest = cdist(scale.transform(test_x), centers).argmin(axis=1)

    predictions = {
        "Default SVM": svm.predict(test_x),
        "Pairwise cutoffs": predict_with_pairwise_cutoffs(
            devices, scores_cal, cal_y, scores_test
        ),
        "SVM score calibration": score_model.predict(scores_test),
        "Nearest outdoor center": devices[nearest],
    }

    recall = {}
    for name, predicted in predictions.items():
        matrix = confusion_matrix(test_y, predicted, labels=devices)
        correct = matrix.trace()
        print(f"{name}: {correct}/{len(test_y)} ({correct / len(test_y):.2%})")
        recall[name] = 100 * matrix.diagonal() / matrix.sum(axis=1)

    print("\nPer-device recall (%)")
    print(pd.DataFrame(recall, index=[f"No_{n}" for n in devices]).round(2).to_string())

    if gatekeeper:
        print("\nClaimed-device verification on the same outdoor test frames")
        print("Incorrect claims use the other known device IDs for each frame.")
        genuine = test_y[:, None] == devices
        always_routed = np.ones_like(genuine)
        for name in ("Default SVM", "SVM score calibration"):
            accepted = predictions[name][:, None] == devices
            report_verification(name, accepted, genuine, always_routed)

        def predict_calibrated(frames):
            scores = svm.decision_function(frames).reshape(len(frames), -1)
            return score_model.predict(scores)

        evaluate_gatekeeper(
            indoor, test_x, test_y, devices, svm.predict, "Indoor-profile cascade"
        )
        evaluate_gatekeeper(
            outdoor_calibration, test_x, test_y, devices,
            predict_calibrated, "Outdoor-profile cascade",
        )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, required=True,
                        help="Folder containing scenario folders or feature CSVs.")
    parser.add_argument("--format", choices=["mat", "csv"], default="mat")
    parser.add_argument(
        "--features", choices=[*FEATURE_SETS, "compare"],
        help="Defaults to compare for MATLAB recordings and phase for legacy CSVs.",
    )
    parser.add_argument("--devices", type=int, nargs="+", default=DEFAULT_DEVICES,
                        help="Device numbers. Defaults to 1, 2, and 10 through 26.")
    parser.add_argument(
        "--mahalanobis", action="store_true",
        help="Also evaluate Tier 1 Mahalanobis verification and Tier 2 SVM routing.",
    )
    args = parser.parse_args()
    devices = np.array(sorted(set(args.devices)))
    if len(devices) < 2 or devices[0] < 1:
        parser.error("--devices requires at least two distinct positive device IDs.")

    selection = args.features or ("compare" if args.format == "mat" else "phase")
    if args.format == "csv" and selection != "phase":
        parser.error("Use raw MATLAB recordings to calculate I/Q statistics.")
    feature_sets = FEATURE_SETS if selection == "compare" else {
        selection: FEATURE_SETS[selection]
    }
    columns = FEATURE_SETS["combined"] if selection == "compare" else FEATURE_SETS[selection]

    try:
        indoor = [load_features(args.data_dir, args.format, INDOOR, n, columns) for n in devices]
        outdoor = [load_features(args.data_dir, args.format, OUTDOOR, n, columns) for n in devices]
        for name, selected_columns in feature_sets.items():
            print(f"\nFeature set: {name} ({', '.join(selected_columns)})")
            evaluate(
                [frames[selected_columns].to_numpy() for frames in indoor],
                [frames[selected_columns].to_numpy() for frames in outdoor],
                devices,
                gatekeeper=args.mahalanobis,
            )
    except (OSError, ValueError, KeyError) as error:
        parser.exit(2, f"Error: {error}\n")


if __name__ == "__main__":
    main()
