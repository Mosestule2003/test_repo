"""Export held-out ZigBee packet decisions for offline dashboard replay."""

import argparse
import json
from pathlib import Path

import numpy as np

from compare_los_nlos import (
    CALIBRATION_FRAMES, comparison_protocol, load_capture_features, scenario_folders,
)
from evaluate_preamble_gatekeeper import FEATURE_SETS, fit_gatekeeper, pack
from signal_features import DEVELOPMENT_DEVICES, RESERVED_DEVICES

ROOT = Path(__file__).resolve().parent


def paired_folders(root):
    if not root.is_dir():
        raise ValueError(f"Dataset directory does not exist: {root}")
    folders = scenario_folders(root)
    if not folders:
        candidates = [scenario_folders(child) for child in root.iterdir() if child.is_dir()]
        matches = [candidate for candidate in candidates if candidate]
        if len(matches) != 1:
            raise ValueError(f"Pass the dataset folder containing the scenario folders under {root}.")
        folders = matches[0]

    visibility = []
    for name in ("NLOS", "LOS"):
        pair = (f"Indoor_{name}", f"Outdoor_{name}")
        present = [condition for condition in pair if condition in folders]
        if len(present) == 1:
            raise ValueError(f"Both {pair[0]} and {pair[1]} are needed for {name} replay.")
        if present:
            visibility.append(name)
    return folders, visibility


def build_replays(features, frame_numbers, visibility):
    enrolled = np.array(DEVELOPMENT_DEVICES)
    later = slice(CALIBRATION_FRAMES, None)
    runs = []
    for name in visibility:
        for mode in ("outdoor_calibrated", "indoor_only"):
            protocol = comparison_protocol(name, mode)
            _, train, profile, test, _ = protocol
            for group in reversed(FEATURE_SETS):
                verify, low, high = fit_gatekeeper(features, group, enrolled, protocol)
                unknown, senders = pack(features, test, group, RESERVED_DEVICES, later)
                trace = verify(unknown)
                packets = {}
                for sender in RESERVED_DEVICES:
                    packet_rows = []
                    indices = np.flatnonzero(senders == sender)
                    for frame, index in zip(frame_numbers[test, sender][later], indices):
                        selected = int(trace.selected[index])
                        packet_rows.append([
                            int(frame),
                            selected if selected != -1 else None,
                            trace.distances[index].tolist(),
                            np.flatnonzero(trace.routed[index]).tolist(),
                            np.flatnonzero(trace.accepted[index]).tolist(),
                        ])
                    packets[sender] = packet_rows
                runs.append({
                    "training": train,
                    "profile": profile,
                    "test": test,
                    "features": group,
                    "thresholds": list(zip(low, high)),
                    "packets": packets,
                })
    return {"enrolled": DEVELOPMENT_DEVICES, "runs": runs}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, default=ROOT / "dashboard" / "packet-data.js")
    args = parser.parse_args()
    try:
        folders, visibility = paired_folders(args.data_dir.resolve())
        data = build_replays(*load_capture_features(folders), visibility)
        script = json.dumps(data, separators=(",", ":"), allow_nan=False)
        args.output.write_text(f"window.RF_PACKET_REPLAYS = {script};\n", encoding="utf-8")
    except (OSError, ValueError, KeyError) as error:
        parser.exit(2, f"{error}\n")
    print(f"Wrote {len(data['runs'])} packet replay evaluations to {args.output.resolve()}")


if __name__ == "__main__":
    main()
