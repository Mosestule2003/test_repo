from pathlib import Path
import numpy as np

import evaluate_rf_classifier as evaluation
from compare import recording_path

ids = np.array(evaluation.DEFAULT_DEVICES)
modes = ("raw", "unit_rms", "dc_and_unit_rms", "dc_rms_and_phase_drift")


def grab_windows(path):
    samples, indices = evaluation.read_mat(path)
    start, end = indices.astype(int).T
    assert np.all(end - start + 1 >= 682)
    windows = samples[(start - 1)[:, None] + np.arange(170, 682)]
    assert np.isfinite(windows).all()
    return windows


def features(w):
    moments = evaluation.calculate_iq_moments(w)
    a, b = w[:, :-1], w[:, 1:]
    valid = (a != 0) & (b != 0)
    phase = np.angle(b * a.conj())
    counts = valid.sum(axis=1)
    out = np.column_stack([
        moments, (np.sin(phase)*valid).sum(axis=1) / counts,
        (np.cos(phase)*valid).sum(axis=1) / counts,
    ])
    assert np.isfinite(out).all()
    return out


def rms_normalize(w):
    rms = np.sqrt(np.mean(abs(w)**2, axis=1, keepdims=True))
    assert np.all(rms > 0)
    return w/rms


cache = Path("rf_scratch/raw_normalization_features.npz")
if not cache.exists():
    cache.parent.mkdir(exist_ok=True)
    data = {}
    for device in ids:
        for condition, short in [("indoor", "in"), ("outdoor", "out")]:
            raw = grab_windows(recording_path(short, device))
            centered = rms_normalize(raw - raw.mean(axis=1, keepdims=True))
            lag_product = centered[:, 1:] * centered[:, :-1].conj()
            phase_step = np.angle(np.sum(lag_product, axis=1))
            rotation = np.exp(-1j * phase_step[:, None] * np.arange(raw.shape[1]))
            variants = [raw, rms_normalize(raw), centered, centered * rotation]
            for mode, window in zip(modes, variants):
                data[f"{mode}_{condition}_{device}"] = features(window)
        print("Extracted device", device, flush=True)
    np.savez_compressed(cache, **data)

with np.load(cache) as data:
    for mode in modes:
        for source, target in [("indoor", "outdoor"), ("outdoor", "indoor")]:
            train, train_y = evaluation.stack_by_device(
                [data[f"{mode}_{source}_{n}"] for n in ids], ids
            )
            target_groups = [data[f"{mode}_{target}_{n}"] for n in ids]
            cut = [len(frames)*3//10 for frames in target_groups]
            test, test_y = evaluation.stack_by_device([f[k:] for f, k in zip(target_groups, cut)], ids)
            model = evaluation.make_pipeline(evaluation.StandardScaler(), evaluation.SVC()).fit(train, train_y)
            predictions = model.predict(test)
            matrix = evaluation.confusion_matrix(test_y, predictions, labels=ids)
            print(
                mode, source, "to", target, int(matrix.trace()), len(test_y),
                f"{matrix.trace()/len(test_y):.2%}", "zero-recall devices", int((matrix.diagonal()==0).sum()),
                flush=True
            )

            if source == "indoor":
                cal_x, cal_y = evaluation.stack_by_device(
                    [f[:k] for f, k in zip(target_groups, cut)], ids
                )
                score_model = evaluation.make_pipeline(
                    evaluation.StandardScaler(),
                    evaluation.LogisticRegression(C=1, max_iter=2000),
                )
                model.set_params(svc__decision_function_shape="ovo")
                score_model.fit(model.decision_function(cal_x), cal_y)
                calibrated = score_model.predict(model.decision_function(test))
                print(mode, "outdoor-calibrated", f"{np.mean(calibrated == test_y):.2%}")
