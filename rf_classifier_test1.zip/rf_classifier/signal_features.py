"""Unified signal preprocessing and feature extraction for WSN/IoT RFF."""

from pathlib import Path
import numpy as np
import pandas as pd
from scipy.io import loadmat

DEFAULT_DEVICES = [1, 2, *range(10, 27)]
DEVELOPMENT_DEVICES = [1, 2, *range(10, 20)]
RESERVED_DEVICES = list(range(20, 27))

INDOOR = "Indoor_NLOS"
OUTDOOR = "Outdoor_NLOS"

IQ_WINDOW_START = 170
IQ_WINDOW_END = 682

PHASE_COLUMNS = ["phase_sin", "phase_cos"]
STAT_COLUMNS = [
    f"{component}_{statistic}"
    for component in ("i", "q")
    for statistic in ("variance", "skewness", "excess_kurtosis")
]
COMBINED_COLUMNS = STAT_COLUMNS + PHASE_COLUMNS


def read_mat(path: Path):
    """Read complex I/Q samples and frame index bounds from MATLAB v5 or v7.3 files."""
    try:
        data = loadmat(path, variable_names=["all_data_segement", "data_index"])
        return np.asarray(data["all_data_segement"]).ravel(), np.asarray(data["data_index"])
    except NotImplementedError:
        try:
            import h5py
        except ImportError as error:
            raise ValueError(
                f"{path.name} uses MATLAB 7.3 (HDF5). Install h5py to read it."
            ) from error
        with h5py.File(path, "r") as data:
            samples = np.asarray(data["all_data_segement"]).ravel()
            indices = np.asarray(data["data_index"]).T
        if samples.dtype.names == ("real", "imag"):
            samples = samples["real"] + 1j * samples["imag"]
        return samples, indices


def load_valid_frames(path: Path, min_samples: int = 8384):
    """Load complete, finite complex I/Q frames using 1-based MATLAB indices."""
    return load_indexed_frames(path, min_samples)[0]


def load_indexed_frames(path: Path, min_samples: int):
    """Return usable frame windows and their original one-based frame numbers."""
    samples, indices = read_mat(path)
    return indexed_frame_windows(samples, indices, min_samples, path)


def indexed_frame_windows(samples, indices, min_samples, path):
    """Extract frame prefixes from a recording already loaded in memory."""
    if not np.iscomplexobj(samples):
        raise ValueError(f"{path} must contain complex I/Q samples.")
    if indices.ndim != 2 or indices.shape[1] != 2 or len(indices) == 0:
        raise ValueError(f"{path} must contain a non-empty N-by-2 data_index.")
    if not np.isfinite(indices).all() or np.any(indices != np.floor(indices)):
        raise ValueError(f"{path} contains non-integer or non-finite frame indices.")

    starts, ends = indices.astype(np.int64).T
    if np.any(starts < 1) or np.any(ends < starts) or np.any(ends > len(samples)):
        raise ValueError(f"{path} contains frame indices outside the recording.")

    lengths = ends - starts + 1
    complete = lengths >= min_samples
    if not np.any(complete):
        raise ValueError(f"{path} has no frames with at least {min_samples} samples.")

    starts_c = starts[complete] - 1
    frames = samples[starts_c[:, None] + np.arange(min_samples)]
    finite_mask = np.isfinite(frames).all(axis=1)
    frames = frames[finite_mask]
    skipped = int(len(indices) - len(frames))
    if skipped > 0:
        print(f"{path.name}: skipped {skipped} incomplete/non-finite frames")
    return frames, np.flatnonzero(complete)[finite_mask] + 1


def normalize_frames(windows: np.ndarray, mode: str = "dc_and_unit_rms") -> np.ndarray:
    """Apply controlled frame normalization without destructive linear phase rotation."""
    w = np.asarray(windows)
    if mode == "raw":
        return w
    if mode == "unit_rms":
        rms = np.sqrt(np.mean(np.abs(w) ** 2, axis=1, keepdims=True))
        return w / np.maximum(rms, 1e-12)
    if mode == "dc_and_unit_rms":
        centered = w - np.mean(w, axis=1, keepdims=True)
        rms = np.sqrt(np.mean(np.abs(centered) ** 2, axis=1, keepdims=True))
        return centered / np.maximum(rms, 1e-12)
    raise ValueError(f"Unknown normalization mode: {mode}")


def calculate_iq_moments(windows: np.ndarray) -> np.ndarray:
    """Return population variance, skewness, and excess kurtosis for I and Q."""
    columns = []
    for component in (windows.real, windows.imag):
        centered = component - np.mean(component, axis=1, keepdims=True)
        variance = np.mean(centered ** 2, axis=1)
        denom = np.sqrt(np.maximum(variance, 1e-24))[:, None]
        standardized = centered / denom
        columns.extend([
            variance,
            np.mean(standardized ** 3, axis=1),
            np.mean(standardized ** 4, axis=1) - 3.0,
        ])
    return np.column_stack(columns)


def phase_step_features(windows: np.ndarray) -> np.ndarray:
    """Mean sin/cos of sample-to-sample phase differences."""
    a, b = windows[:, :-1], windows[:, 1:]
    valid = (np.abs(a) > 0) & (np.abs(b) > 0)
    counts = np.maximum(valid.sum(axis=1), 1)
    diff = np.angle(b * np.conj(a))
    sin_mean = (np.sin(diff) * valid).sum(axis=1) / counts
    cos_mean = (np.cos(diff) * valid).sum(axis=1) / counts
    return np.column_stack([sin_mean, cos_mean])


def magnitude_shape_features(windows: np.ndarray) -> np.ndarray:
    """Amplitude quantiles and normalized moments on a steady window."""
    amp = np.abs(windows)
    rms = np.sqrt(np.mean(amp ** 2, axis=1, keepdims=True))
    norm = amp / np.maximum(rms, 1e-12)
    quantiles = np.quantile(norm, [0.10, 0.25, 0.50, 0.75, 0.90, 0.99], axis=1).T
    moments = np.column_stack([np.mean(norm ** k, axis=1) for k in (1, 3, 4, 6)])
    return np.column_stack([quantiles, moments])


def acf_features(windows: np.ndarray, amplitude: bool = False) -> np.ndarray:
    """Normalized autocorrelation magnitudes across multi-scale lags."""
    z = np.abs(windows) if amplitude else windows.astype(np.complex128, copy=True)
    if amplitude:
        z = z - np.mean(z, axis=1, keepdims=True)
    lags = [1, 2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 24, 32, 40, 48, 64, 80, 96, 128, 160, 192, 256, 320, 384, 512, 640]
    cols = []
    for lag in lags:
        if z.shape[1] <= lag:
            continue
        a, b = z[:, :-lag], z[:, lag:]
        scale = np.sqrt(np.sum(np.abs(a) ** 2, axis=1) * np.sum(np.abs(b) ** 2, axis=1))
        cols.append(np.abs(np.sum(b * np.conj(a), axis=1)) / np.maximum(scale, 1e-12))
    return np.column_stack(cols)


def spectrum_features(windows: np.ndarray, centered: bool = True) -> np.ndarray:
    """32-bin log Welch PSD with optional circular spectral-centroid alignment."""
    usable_len = (windows.shape[1] // 1024) * 1024
    if usable_len < 1024:
        raise ValueError("Need at least 1024 samples for 1024-point spectrum features.")
    n_blocks = usable_len // 1024
    blocks = windows[:, :usable_len].reshape(len(windows), n_blocks, 1024)
    win = np.hanning(1024)
    fft_mag = np.abs(np.fft.fftshift(np.fft.fft(blocks * win, axis=-1), axes=-1)) ** 2
    psd = np.mean(fft_mag, axis=1)
    psd = psd / np.maximum(psd.sum(axis=1, keepdims=True), 1e-12)
    if centered:
        n_bins = psd.shape[1]
        angles = 2j * np.pi * np.arange(n_bins) / n_bins
        centroid = np.angle(psd @ np.exp(angles)) * n_bins / (2.0 * np.pi)
        shift = np.rint(centroid).astype(int)[:, None] - n_bins // 2
        idx = (np.arange(n_bins)[None, :] + shift) % n_bins
        psd = np.take_along_axis(psd, idx, axis=1)
    binned = psd.reshape(len(windows), 32, n_bins // 32).sum(axis=2)
    return np.log10(binned + 1e-12)


def preamble_features(frames: np.ndarray, start: int = 170) -> dict[str, np.ndarray]:
    """Extract repeated-block phase alignment, residual error, and preamble shape."""
    end = start + 6 * 160
    if start < 0 or frames.shape[1] < end:
        raise ValueError(f"Preamble window {start}:{end} is outside the available samples.")
    blocks = frames[:, start:end].reshape(len(frames), 6, 160)
    corr = (blocks[:, 1:] * np.conj(blocks[:, :-1])).sum(axis=2)
    drift_raw = corr.sum(axis=1)
    drift = np.exp(1j * np.angle(drift_raw))
    aligned = blocks * (drift[:, None, None] ** (-np.arange(6)[None, :, None]))
    avg = aligned.mean(axis=1)
    norm = avg / np.maximum(np.sqrt(np.mean(np.abs(avg) ** 2, axis=1, keepdims=True)), 1e-12)

    residual = np.mean(np.abs(aligned - avg[:, None, :]) ** 2, axis=2)
    block_power = np.maximum(np.mean(np.abs(aligned) ** 2, axis=2), 1e-12)
    repeat_error = np.log10(np.maximum(residual / block_power, 1e-12))

    preamble_acf = np.column_stack([
        np.abs(np.mean(np.roll(norm, lag, axis=1) * np.conj(norm), axis=1))
        for lag in (1, 2, 3, 4, 5, 8, 10, 15, 20, 30, 40, 60, 80)
    ])
    preamble_phase_lags = np.column_stack([
        np.angle(np.mean(np.roll(norm, lag, axis=1) * np.conj(norm), axis=1))
        for lag in (1, 2, 3, 4, 5, 8, 10)
    ])
    return {
        "repeated_phase": np.column_stack([drift.real, drift.imag]),
        "repeat_error": repeat_error,
        "preamble_acf": preamble_acf,
        "preamble_phase": preamble_phase_lags,
    }


def extract_feature_dict(frames: np.ndarray, norm_mode: str = "dc_and_unit_rms") -> dict[str, np.ndarray]:
    """Extract modular feature groups from full frames (e.g., 8384 samples)."""
    win512 = normalize_frames(frames[:, IQ_WINDOW_START:IQ_WINDOW_END], mode=norm_mode)
    steady = normalize_frames(frames[:, 170:], mode=norm_mode)
    steady_power = np.maximum(np.mean(np.abs(frames[:, 170:]) ** 2, axis=1), 1e-12)
    onset_env = np.column_stack([
        np.log10(
            np.maximum(np.mean(np.abs(frames[:, start:stop]) ** 2, axis=1), 1e-12)
            / steady_power
            + 1e-12
        )
        for start, stop in zip(range(0, 320, 20), range(20, 340, 20))
    ])

    iq_stats = calculate_iq_moments(win512)
    phase512 = phase_step_features(win512)
    out = {
        "iq_stats": iq_stats,
        "phase512": phase512,
        "combined512": np.column_stack([iq_stats, phase512]),
        "amplitude_shape": magnitude_shape_features(steady),
        "onset_envelope": onset_env,
        "complex_acf": acf_features(steady, amplitude=False),
        "amplitude_acf": acf_features(steady, amplitude=True),
        "centered_spectrum": spectrum_features(steady, centered=True),
    }
    if frames.shape[1] >= 1130:
        out.update(preamble_features(frames))
    return out


def extract_legacy_dataframe(path: Path, columns: list[str], norm_mode: str = "dc_and_unit_rms") -> pd.DataFrame:
    """Backward-compatible DataFrame extractor for evaluate_rf_classifier workflows."""
    frames = load_valid_frames(path, min_samples=IQ_WINDOW_END)
    win512 = normalize_frames(frames[:, IQ_WINDOW_START:IQ_WINDOW_END], mode=norm_mode)
    df = pd.DataFrame(index=np.arange(len(win512)))
    if any(col in STAT_COLUMNS for col in columns):
        df[STAT_COLUMNS] = calculate_iq_moments(win512)
    if any(col in PHASE_COLUMNS for col in columns):
        df[PHASE_COLUMNS] = phase_step_features(win512)
    df = df[columns]
    return df.loc[np.isfinite(df.to_numpy()).all(axis=1)].reset_index(drop=True)
