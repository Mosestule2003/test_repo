"""Blocked within-condition, cross-condition, and unknown-device tests."""
import numpy as np
from sklearn.covariance import LedoitWolf
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

IDS = np.array([1, 2, *range(10, 27)])
KNOWN = np.array([1, 2, *range(10, 20)])
UNKNOWN = np.arange(20, 27)


def load():
    data = {}
    with np.load("rf_scratch/raw_normalization_features.npz") as raw, np.load("rf_scratch/features.npz") as long:
        for cond, prefix in [("indoor", "in"), ("outdoor", "out")]:
            for n in IDS:
                normalized = raw[f"dc_and_unit_rms_{cond}_{n}"]
                shape = np.column_stack([
                    long[f"{prefix}_{n}_{name}"] for name in
                    ("amplitude_shape", "amplitude_acf", "centered_spectrum")
                ])
                data[cond, n] = {
                    "iq_phase": normalized,
                    "shape": shape,
                    "iq_phase_and_shape": np.column_stack([normalized, shape]),
                }
    return data


def select(data, cond, group, ids, selection):
    values = [data[cond, n][group] for n in ids]
    chunks = [selection(a) for a in values]
    return np.vstack(chunks), np.repeat(ids, [len(a) for a in chunks])


def row_scores(model, x):
    return model.decision_function(x).reshape(len(x), -1)


def fit_svm(x, y, **params):
    return make_pipeline(StandardScaler(), SVC(decision_function_shape="ovo", **params)).fit(x, y)


def fit_score_model(model, x, y):
    return make_pipeline(
        StandardScaler(), LogisticRegression(C=1, max_iter=2000)
    ).fit(row_scores(model, x), y)


def select_parameters(data, condition, group):
    # Restrict tuning to the first 70% of each source capture.
    early = select(data, condition, group, IDS, lambda a: a[:len(a)*5//10])
    validation = select(data, condition, group, IDS, lambda a: a[len(a)*5//10:len(a)*7//10])
    options = [{"kernel": "linear", "C": c} for c in (.1, 1, 10)]
    options += [{"kernel": "rbf", "C": c, "gamma": gamma}
                for c in (.1, 1, 10) for gamma in ("scale", .1, 1)]
    return max(options, key=lambda p: fit_svm(*early, **p).score(*validation))


def closed_set(data, group, tune):
    for source, target in [("indoor", "outdoor"), ("outdoor", "indoor")]:
        params = select_parameters(data, source, group) if tune else {}
        early = select(data, source, group, IDS, lambda a: a[:len(a)*7//10])
        later = select(data, source, group, IDS, lambda a: a[len(a)*7//10:])
        within = fit_svm(*early, **params).score(*later)
        full = select(data, source, group, IDS, lambda a: a)
        test_x, test_y = select(data, target, group, IDS, lambda a: a[len(a)*3//10:])
        model = fit_svm(*full, **params)
        cross = model.score(test_x, test_y)
        outputs = [within, cross]
        budgets = []
        for pct in (5, 15, 30):
            cal_x, cal_y = select(data, target, group, IDS, lambda a: a[:len(a)*pct//100])
            calibrator = fit_score_model(model, cal_x, cal_y)
            outputs.append(calibrator.score(row_scores(model, test_x), test_y))
            budgets.append(len(cal_y))
        print(group, source, params, "test size", len(test_y), "budgets", budgets,
              "within / zero / 5 / 15 / 30", [round(v*100,2) for v in outputs], flush=True)


def open_set(data):
    # Reserved IDs never enter training, enrollment or threshold selection.
    group = "iq_phase"
    x, y = select(data, "indoor", group, KNOWN, lambda a: a)
    model = fit_svm(x, y)
    enroll_x, enroll_y = select(data, "outdoor", group, KNOWN, lambda a: a[:34])
    cal_x, cal_y = select(data, "outdoor", group, KNOWN, lambda a: a[34:51])
    val_x, val_y = select(data, "outdoor", group, KNOWN, lambda a: a[51:69])
    cal = fit_score_model(model, cal_x, cal_y)
    scale = StandardScaler().fit(enroll_x)
    enrollment = scale.transform(enroll_x)
    profiles = [LedoitWolf().fit(enrollment[enroll_y == n]) for n in KNOWN]
    val_scaled = scale.transform(val_x)
    val_dist = np.column_stack([p.mahalanobis(val_scaled) for p in profiles])
    val_correct = val_y[:,None] == KNOWN
    wrong_min = np.min(np.where(val_correct, np.inf, val_dist), axis=0)
    known_x, known_y = select(data, "outdoor", group, KNOWN, lambda a: a[69:])
    unknown_x, _ = select(data, "outdoor", group, UNKNOWN, lambda a: a[69:])
    dist_known = np.column_stack([p.mahalanobis(scale.transform(known_x)) for p in profiles])
    dist_unknown = np.column_stack([p.mahalanobis(scale.transform(unknown_x)) for p in profiles])
    known_mask = known_y[:, None] == KNOWN
    known_scores = cal.predict(row_scores(model, known_x))[:,None] == KNOWN
    unknown_scores = cal.predict(row_scores(model, unknown_x))[:,None] == KNOWN
    print("open set known and unknown frames", len(known_x), len(unknown_x),flush=True)
    for low_percentile, high_percentile in [(50,90), (50,99), (70,95), (90,99), (90,100), (90,None)]:
        def thresholds(p):
            return np.array([np.percentile(val_dist[val_correct[:,i],i],p) for i in range(len(KNOWN))])
        low = np.minimum(thresholds(low_percentile), np.nextafter(wrong_min,-np.inf))
        high = np.inf if high_percentile is None else thresholds(high_percentile)
        r1=(dist_known>low)&(dist_known<=high)
        r2=(dist_unknown>low)&(dist_unknown<=high)
        unknown_accepted=(dist_unknown<=low)|(r2&unknown_scores)
        genuine=(dist_known<=low)|(r1&known_scores)
        print("thresholds",low_percentile,high_percentile,
              "genuine/wrong-known/route/unknown FAR",round(genuine[known_mask].mean()*100,2),
              round(genuine[~known_mask].mean()*100,2),round(r1[known_mask].mean()*100,2),
              round(unknown_accepted.any(axis=1).mean()*100,2), flush=True)
    print("SVM always predicts a known class. Genuine accuracy", known_scores[known_mask].mean(),
          "unknown accepted by at least one ID", unknown_scores.any(axis=1).mean(),flush=True)


if __name__ == "__main__":
    data=load()
    for group in ("iq_phase", "shape", "iq_phase_and_shape"):
        closed_set(data, group, tune=False)
    closed_set(data, "iq_phase", tune=True)
    open_set(data)
