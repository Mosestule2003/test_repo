"""Export a compact snapshot of real benchmark signals for the local dashboard."""

import argparse
import csv
import json
import webbrowser
from pathlib import Path

import numpy as np

from compare_los_nlos import resolve_scenario_folders, scenario_folders
from signal_features import (
    DEFAULT_DEVICES, DEVELOPMENT_DEVICES, INDOOR, OUTDOOR,
    IQ_WINDOW_START, IQ_WINDOW_END, STAT_COLUMNS,
    calculate_iq_moments, normalize_frames, read_mat,
)

ROOT = Path(__file__).resolve().parent
SAMPLE_COUNT = 768
SCENARIOS = {
    INDOOR: {
        "label": "Indoor NLOS", "distance": "32.8 m at the shortest point",
        "description": "Transmitter in a corridor, receiver in a room on the same floor.",
    },
    OUTDOOR: {
        "label": "Outdoor NLOS", "distance": "About 24.7 m",
        "description": "Transmitter on a balcony, receiver in a corridor of another building. A wall obstructed each end.",
    },
    "Indoor_LOS": {
        "label": "Indoor LOS", "distance": "About 3 m",
        "description": "Indoor transmitter and receiver with a clear line of sight.",
    },
    "Outdoor_LOS": {
        "label": "Outdoor LOS", "distance": "About 50 m",
        "description": "Transmitter visible from the receiver, with two trees next to the path.",
    },
}


def recording(folder, condition, device):
    path = folder / f"No_{device}_F5_1.mat"
    signal, indices = read_mat(path)
    return recording_preview(path, condition, device, signal, indices)


def recording_preview(path, condition, device, signal, indices):
    """Make dashboard previews from samples already in memory."""
    if (indices.ndim != 2 or indices.shape[1] != 2 or not len(indices)
            or not np.isfinite(indices).all() or np.any(indices != np.floor(indices))):
        raise ValueError(f"Invalid frame indices in {path}")
    starts, ends = indices.astype(np.int64).T
    lengths = ends - starts + 1
    if (np.any(starts < 1) or np.any(lengths <= 0) or np.any(ends > signal.size)
            or not np.iscomplexobj(signal)):
        raise ValueError(f"Invalid I/Q frame bounds in {path}")
    example_indices = sorted({0, len(starts) // 2, len(starts) - 1})
    examples = []
    for index in example_indices:
        start, end = starts[index], ends[index]
        values = signal[start - 1: min(end, start - 1 + SAMPLE_COUNT)]
        if not np.isfinite(values).all():
            raise ValueError(f"Non-finite I/Q in {path} frame {index + 1}")
        iq_moments = None
        if len(values) >= IQ_WINDOW_END:
            window = values[None, IQ_WINDOW_START:IQ_WINDOW_END]
            normalized = normalize_frames(window, mode="dc_and_unit_rms")
            iq_moments = dict(zip(STAT_COLUMNS, calculate_iq_moments(normalized)[0].tolist()))
        examples.append({
            "number": index + 1,
            "start": int(start),
            "end": int(end),
            "i": np.round(values.real, 8).tolist(),
            "q": np.round(values.imag, 8).tolist(),
            "iq_moments": iq_moments,
        })
    return {
        "device": device,
        "condition": condition,
        "file": f"{path.parent.name}/{path.name}",
        "frames": len(starts),
        "samples": int(signal.size),
        "size": path.stat().st_size,
        "pa": device <= 12 or device in (20, 22, 26),
        "enrolled": device in DEVELOPMENT_DEVICES,
        "capture": 1,
        "power_register": "F5",
        "previews": examples,
    }


def build(dataset, results, comparison=None):
    if comparison is not None:
        folders = resolve_scenario_folders(dataset)
    else:
        folders = scenario_folders(dataset)
        missing = [condition for condition in (INDOOR, OUTDOOR) if condition not in folders]
        if missing:
            raise ValueError(f"Missing scenario folders in {dataset}: {', '.join(missing)}")
    metrics = load_metrics(results)
    if comparison is not None:
        metrics.extend(load_metrics(comparison))
    scenarios = {key: value for key, value in SCENARIOS.items() if key in folders}
    recordings = [
        recording(folders[condition], condition, device)
        for device in DEFAULT_DEVICES for condition in scenarios
    ]
    return {"scenarios": scenarios, "recordings": recordings, "results": metrics}


def load_metrics(results):
    with results.open(encoding="utf-8", newline="") as stream:
        metrics = []
        for row in csv.DictReader(stream):
            for key in ("count", "total"):
                row[key] = int(row[key])
            row["rate_percent"] = float(row["rate_percent"])
            metrics.append(row)
    if not metrics:
        raise ValueError("No evaluation results in the metrics CSV.")
    return metrics


def write_dashboard_data(payload, path):
    with path.open("w", encoding="utf-8", newline="\n") as stream:
        stream.write("window.RF_DASHBOARD_DATA = ")
        json.dump(payload, stream, separators=(",", ":"), allow_nan=False)
        stream.write(";\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, required=True)
    parser.add_argument("--results", type=Path, default=ROOT / "gatekeeper_results.csv")
    parser.add_argument("--comparison", type=Path, help="CSV produced by compare_los_nlos.py.")
    parser.add_argument("--output", type=Path, default=ROOT / "dashboard" / "dashboard-data.js")
    parser.add_argument("--open", action="store_true", help="Open the dashboard just rebuilt.")
    args = parser.parse_args()
    output = args.output.resolve()
    page = output.with_name("index.html")
    if args.open and (output.name != "dashboard-data.js" or not page.is_file()):
        parser.error("--open needs dashboard-data.js beside the dashboard's index.html.")
    try:
        payload = build(args.data_dir.resolve(), args.results, args.comparison)
        write_dashboard_data(payload, output)
    except (OSError, ValueError, KeyError) as error:
        parser.exit(2, f"{error}\n")
    labels = ", ".join(condition["label"] for condition in payload["scenarios"].values())
    print(f"Loaded {len(payload['scenarios'])} conditions and {len(payload['recordings'])} recordings: {labels}")
    print(f"Dashboard data: {output}")
    if page.is_file():
        print(f"Dashboard page: {page}")
    if args.open and not webbrowser.open(page.as_uri(), new=2):
        print("Open the dashboard page above in your browser.")


if __name__ == "__main__":
    main()
