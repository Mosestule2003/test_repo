/*
  HTS221 - Read Sensors (file-logging version)

  Prints ONE line of JSON per reading, for example:
    {"temperatureC":23.91,"humidityPct":36.58,"pressureKpa":101.25}

  - log_serial.py on the Mac reads these lines and appends them to a CSV file.
  - The same lines also work with the RF dashboard:  python src dashboard --serial /dev/cu.usbmodemXXXX

  Lines that start with "#" are status messages; the logger skips them.
  IMPORTANT: close the Arduino IDE Serial Monitor before running log_serial.py.
  Only one program can use the USB port at a time.
*/

#include <Arduino_MKRIoTCarrier.h>
MKRIoTCarrier carrier;

const unsigned long REPORT_EVERY_MS = 1000;   // one reading per second, as before

void setup() {
  Serial.begin(115200);                       // matches log_serial.py and the dashboard (config.py)
  unsigned long waitStart = millis();
  while (!Serial && millis() - waitStart < 3000) { }   // don't hang forever if no computer is reading

  carrier.noCase();
  if (!carrier.begin()) {
    Serial.println("# WARNING: carrier.begin() failed - check the board is seated on the carrier");
  }
  Serial.println("# ready");
}

void loop() {
  float temperature = carrier.Env.readTemperature();    // °C
  float humidity    = carrier.Env.readHumidity();       // %
  float pressure    = carrier.Pressure.readPressure();  // kPa

  Serial.print("{\"temperatureC\":"); Serial.print(temperature, 2);
  Serial.print(",\"humidityPct\":");  Serial.print(humidity, 2);
  Serial.print(",\"pressureKpa\":");  Serial.print(pressure, 2);
  Serial.println("}");

  delay(REPORT_EVERY_MS);
}
